<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Session;
use Excel;
use App\Calculator;
use App\DuctRelation;
use App\DesignCondition;
use App\DesignOption;
use App\Project;
use App\ProjectListing;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use DB;
use PDF;
use Illuminate\Support\Facades\Redirect;
use Exception;
class CalculatorController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    public $Wsl=0;
    public $Wsd=0;
    
  
	 
    
      /** 
		* author						: IDS infotech limited
		* function						: index()
		* Purpose						: Its pupose to display duct calculator at load time  we have called several fuctions with
										: different parameters here we have created leftpanel dropdown like connecting flange 
										: and stiffener dropdown.
		* description					: We have created a design option for all like fixed/unfixed in all layouts
		* Argument						: Passed inside parameter
			$request					: Form data passed in this parameters
		* created						: 25 April 2018
		* modified						: NA
	 */
	 
	 
    public function index(Request $request){
		
				session_start();
				unset($_SESSION['spacing_val']);
				 $crLoads=array();
				 $crLoads['toppanel']=array();
				 $crLoads['bottompanel']=array();
				 $crLoads['sidepanel']=array();
				 $step5=array();
				 $designoptions=array();
				 $designNoUnfixed=array();
				 $designYesUnfixed=array();
				 $gage_number=array();
				 $new_outer_array=array();
				 $design=array();
				 $designNofixed=array();
				 $designNoUnfixed=array();
				 $connecting_unfixed_dropdown=array();
				 $connecting_fixed_dropdown=array();
				 $countcr=1;
				 $requestData=$request->all();
				 $default_material_type=1;
				 $particulates = Calculator::getParticulate();
				 $classes =   Calculator::getMaterialClasses();
				 $insulationmaterial =   Calculator::getExtInsType();
				 $lagingmaterial =   Calculator::getLagingType();
				 $ductlinertype =   Calculator::ductLinerType();
				 $doublewallinner =   Calculator::doubleWallMaterial();
				 $zoneData =   Calculator::getZone();
				 $snowData =   Calculator::getSnow();
				 $windData =   Calculator::getWind();
				 $temperature =   Calculator::getTemperature($default_material_type);
				 $getMaterials =   Calculator::getMaterials();
				 
				 if(!empty($requestData['project_code'])){
					 $projectcode=$requestData['project_code'];
					 $projectid=$requestData['project_id'];
					 $status=$requestData['status'];
					 $type=isset($requestData['type'])?$requestData['type']:'';
					
					 if(isset($requestData['duct'])){
						$duct= base64_decode($requestData['duct']);
					 }else{
						$duct='';
					 }
				
					 $exist=array();
					 if(isset($requestData['id']) && $requestData['id']!=''){	
						 $designConditionId = $requestData['id'];
						 $pid=base64_decode($requestData['id']);
						 $exist=DesignCondition::isExist(base64_decode($requestData['id']));	
							if(!empty($duct) && $duct=="same"){	
							  $exist->duct_height='';
							  $exist->duct_width='';
							}
												 						 
					 }else{
						 $designConditionId= '';		
					 }
				}else{					
					$projectcode='';
					$projectid='';
					$exist='';					
					$status=base64_encode(0);	
					$type='';	
					$duct='';	
					$designConditionId= '';					
				}
			 if($_POST){ //Post data here
					
					if($requestData['internal_support']=='Yes'){
					  $requestData['internal_support_number'] ='One';							
					}
					
					$xplode=explode('-',$requestData['duct_material']);
					$arraytochecknext =  Calculator::getNextTemperature($requestData['duct_material']);
					$nextarray=array_column(json_decode($arraytochecknext,true),'temperature');	
					
					foreach($nextarray as $next){
						if($next>=$requestData['design_temperature']){
							$temperaturemap =   Calculator::getTemperatureMapping($requestData['duct_material'],$next);
							
							if($temperaturemap){
									break;
							}else{
								
							continue;	
							}
						}
					}
					
					$requestData['mat-classes1']=$requestData['mat-classes'];
					$materailclass_id=Calculator::getMaterialClassesByID($requestData['mat-classes'],$requestData['duct_material']);
					if(empty($materailclass_id)){
						return Redirect::back()->withErrors(['Either class or material or temperature not found.']);
					}
					
					$requestData['mat-classes']=$materailclass_id->id;
					
					$requestData['design_temperature1']=$requestData['design_temperature'];
					
					$requestData['design_temperature']=$temperaturemap->id;
					$temperature =   Calculator::getTemperature($xplode[1]);
					
					$toppanel=$this->getTopCriticalLoad($requestData);
					
					$botpanel=$this->getBottomCriticalLoad($requestData);
					$sidepanel=$this->getSidePanelCriticalLoad($requestData);
					$insthickness = Calculator::getInsulationThick($requestData['ext_ins_type']);	
					
					$crLoads['toppanel']=$toppanel;
					$crLoads['bottompanel']=$botpanel;
					$crLoads['sidepanel']=$sidepanel;
					
					$countcr=count($crLoads['toppanel'])+count($crLoads['bottompanel'])+count($crLoads['sidepanel']);
					$mergestiffiner=array();
					$outer_array=array();
					$selectdefaultarr=array();
					$dropdown=array();
					
					$auxmaterialtype=$this->getMatterialMapping($requestData['duct_material']);
					$returndropdown_fixed='';
					$returndropdown_unfixed='';
					if($countcr>0){
						
						 $requestData['loadtime']=1;
						if($requestData['same_gage']=="Yes"){
							
							$designoptions_fixed=$this->getDesignOptions($requestData,$crLoads);
							
							if($requestData['transverse']=='Connecting Flanges'){
								$connecting_fixed_dropdown=$this->connectingFlangeDropdown($designoptions_fixed,$auxmaterialtype,$type);
							}
												
							$design=$this->getLayoutArr($designoptions_fixed,null,$requestData['duct_material'],$requestData['same_gage'],null,$requestData);
							
							$returndropdown_fixed=$this->stiffenerDropdown($designoptions_fixed,$auxmaterialtype,$type);
							
							
							$requestData['unfixed_flag']=1;
							
							$toppanel_unfixed=$this->getTopCriticalLoad($requestData);
							$botpanel_unfixed=$this->getBottomCriticalLoad($requestData);
							$sidepanel_unfixed=$this->getSidePanelCriticalLoad($requestData);
							$crLoads1['toppanel']=$toppanel_unfixed;
						    $crLoads1['bottompanel']=$botpanel_unfixed;
					        $crLoads1['sidepanel']=$sidepanel_unfixed;
							$designoptions_unfixed=$this->getDesignOptions($requestData,$crLoads1);
							
							
							$requestData['dataFlag']=0;
							$unfixedLayoutYes=$this->getUnfixedLayout($requestData);
							$designYesUnfixed=$unfixedLayoutYes['design'];
							$designoptions_unfixed_yes=$unfixedLayoutYes['designoptions_fixed'];
							$returndropdown_unfixed=$this->stiffenerDropdown($designoptions_unfixed_yes,$auxmaterialtype,$type);
							if($requestData['transverse']=='Connecting Flanges'){
								$designoptions_unfixed_yes=$this->refineDesignOption($designoptions_unfixed_yes);
								$connecting_unfixed_dropdown=$this->connectingFlangeDropdown($designoptions_unfixed_yes,$auxmaterialtype,$type);
							}
							
							
							
						}elseif($requestData['same_gage']=="No"){
							
							$requestData['flag']='fixed';
							$designoptions_fixed=$this->getDesignOptions($requestData,$crLoads);
							if($requestData['transverse']=='Connecting Flanges'){
							$connecting_fixed_dropdown=$this->connectingFlangeDropdown($designoptions_fixed,$auxmaterialtype,$type);	
							}
							$designNofixed=$this->getLayoutArrForNofixed($designoptions_fixed,null,$requestData['duct_material'],$requestData['same_gage'],null);
							
							$returndropdown_fixed=$this->stiffenerDropdown($designoptions_fixed,$auxmaterialtype,$type);
							$requestData['flag']='unfixed';
							
							$requestData['unfixed_flag']=1;
							
							$toppanel_unfixed=$this->getTopCriticalLoad($requestData);
							//echo '<pre>';print_r($toppanel_unfixed);exit;
							$botpanel_unfixed=$this->getBottomCriticalLoad($requestData);
							$sidepanel_unfixed=$this->getSidePanelCriticalLoad($requestData);
							$crLoads1['toppanel']=$toppanel_unfixed;
						    $crLoads1['bottompanel']=$botpanel_unfixed;
					        $crLoads1['sidepanel']=$sidepanel_unfixed;
					      
							$designoptions_unfixed=$this->getDesignOptions($requestData,$crLoads1);
							$designNoUnfixed=$this->getLayoutArrForNoUnfixed($crLoads1,$requestData);
							
							$returndropdown_unfixed=$this->stiffenerDropdownNo($crLoads1,$auxmaterialtype,$type);
							
							
							
							
						}		
					}else{
						
						return Redirect::back()->withErrors(['No Record found.']);
					}
					
					
					$mergestiffiner=$returndropdown_fixed['mergestiffiner'];
					$selectdefaultarr=$returndropdown_fixed['selectdefaultarr'];
					$new_outer_array=$returndropdown_fixed['new_outer_array'];
					
					$mergestiffiner_unfixed=$returndropdown_unfixed['mergestiffiner'];
					$selectdefaultarr_unfixed=$returndropdown_unfixed['selectdefaultarr'];
					$new_outer_array_unfixed=$returndropdown_unfixed['new_outer_array'];
					
					$requestData['duct_material']=$xplode[0].'-'.$xplode[1];
					
					if(isset($requestData['id']) && $requestData['id']!='' && !empty($duct) &&  $duct!="same"){
						$data=array();
						$data['project_id'] =base64_decode($requestData['project_id']);
						$data['project_code'] =base64_decode($requestData['project_code']);
						$data['custom_particulate'] =!empty($requestData['custom_material'])?$requestData['custom_material']:'';
						$data['percentage_full'] =$requestData['percentage_full'];
						$data['perticulate_density'] =$requestData['perticulate_density'];
						$data['particulate_material_id'] =$requestData['particulate_material_id'];
						$data['design_pressure'] =$requestData['design_pressure'];
						$data['positive_negtive_pressure'] =$requestData['positive_negtive_pressure'];
						$data['mat_class_id'] =$requestData['mat-classes'];
						$data['design_temperature_id']  =$requestData['design_temperature'];
						$data['duct_material_id']  =$requestData['duct_material'];
						$data['same_gage']  =$requestData['same_gage'];
						$data['vertical_horigental']  =$requestData['vertical_horigental'];
						$data['transverse']  =$requestData['transverse'];
						$data['internal_support']  =$requestData['internal_support'];
						$data['hanger_spacing_id']  =$requestData['hanger_spacing'];
						$data['ext_ins_type_id']  =$requestData['ext_ins_type'];
						$data['ext_ins_thick_id']  =$requestData['ext_ins_thick'];
						$data['laging_material_id']  =$requestData['laging_material'];
						$data['zone_id']  =$requestData['zone'];
						$data['wind_velocity_id']  =$requestData['wind_velocity'];
						$data['snow_load_id']  =$requestData['snow_load'];
						$data['duct_width']  =$requestData['duct_width'];
						$data['duct_height']  =$requestData['duct_height'];
						\DB::table('design_conditions')->where('id',base64_decode($requestData['id']))->update($data);//update design conditions
						
						 $pid=base64_decode($requestData['id']);
						 $exist=DesignCondition::isExist(base64_decode($requestData['id']));		
					}else{
						if(empty($requestData['project_id']) && empty($duct) && $duct!="same"){	
						
							$addVisitorProject = $this->addVisitorProject();	//visitor user
							$addVisitorProject = json_decode($addVisitorProject);
							$requestData['project_code'] = $addVisitorProject->project_ID;
							$requestData['project_id'] = $addVisitorProject->id;
							$requestData['status'] = $addVisitorProject->encodeStatus;
							
							
							if(!empty($requestData['project_code'])){
								 $projectcode=$requestData['project_code'];
								 $projectid=$requestData['project_id'];
								 $status=$requestData['status'];
								 $type=isset($requestData['type'])?$requestData['type']:'';
							
								 $exist=array();
								 if(isset($requestData['id']) && $requestData['id']!=''){	
									 $designConditionId = $requestData['id'];
									 $pid=base64_decode($requestData['id']);
									 $exist=DesignCondition::isExist(base64_decode($requestData['id']));	
															 
								 }else{
									 $designConditionId= '';		
								 }
							}else{					
								$projectcode='';
								$projectid='';
								$exist='';					
								$status=base64_encode(0);	
								$type='';	
								$designConditionId= '';					
							}
						}					
							$customObj=new DesignCondition;
							$customObj->project_id =base64_decode($requestData['project_id']);
							$customObj->project_code =base64_decode($requestData['project_code']);
							$customObj->custom_particulate =!empty($requestData['custom_material'])?$requestData['custom_material']:'';
							$customObj->percentage_full =$requestData['percentage_full'];
							$customObj->perticulate_density =$requestData['perticulate_density'];
							$customObj->particulate_material_id =$requestData['particulate_material_id'];
							$customObj->design_pressure =$requestData['design_pressure'];
							$customObj->positive_negtive_pressure =$requestData['positive_negtive_pressure'];
							$customObj->mat_class_id =$requestData['mat-classes'];
							$customObj->design_temperature_id  =$requestData['design_temperature'];
							$customObj->duct_material_id  =$requestData['duct_material'];
							$customObj->same_gage  =$requestData['same_gage'];
							$customObj->vertical_horigental  =$requestData['vertical_horigental'];
							$customObj->transverse  =$requestData['transverse'];
							$customObj->internal_support  =$requestData['internal_support'];
							$customObj->hanger_spacing_id  =$requestData['hanger_spacing'];
							$customObj->ext_ins_type_id  =$requestData['ext_ins_type'];
							$customObj->ext_ins_thick_id  =$requestData['ext_ins_thick'];
							$customObj->laging_material_id  =$requestData['laging_material'];
							$customObj->zone_id  =$requestData['zone'];
							$customObj->wind_velocity_id  =$requestData['wind_velocity'];
							$customObj->snow_load_id  =$requestData['snow_load'];
							$customObj->duct_width  =$requestData['duct_width'];
							$customObj->duct_height  =$requestData['duct_height'];
							$customObj->save(); //insert design conditions
							$designConditionId = base64_encode($customObj->id);
						
					}
					
					$duct='update';//make it update						
					$same_gage = $requestData['same_gage'];					
				    $gage_number =   Calculator::getGage($xplode[0]);
					
					/*------------edit case------------------------*/
					 $existDesignOptionFixed=array();
					 $existDesignOptionUnfixed=array();
					 $selected_stiffener_spacing='';
					 $selected_stiffener_spacing_unfixed='';
				
					return view('calculator/index',['particulates'=>$particulates,'classes'=>$classes,'insulationmaterial'=>$insulationmaterial,'laging'=>$lagingmaterial,'ductlinertype'=>$ductlinertype,'doublewallinner'=>$doublewallinner,'zonedata'=>$zoneData,'snowground'=>$snowData,'windData'=>$windData,'temperature'=>$temperature,'gage_number'=>$gage_number,'getMaterials'=>$getMaterials,'project_code'=>$projectcode,'project_id'=>$projectid,'status'=>$status,'exist'=>$exist,'crLoads'=>$crLoads,'requestData'=>$requestData,'thickness'=>$insthickness,'des'=>$design,'designNoUnfixed'=>$designNoUnfixed,'designNofixed'=>$designNofixed,'designYesUnfixed'=>$designYesUnfixed,'step5'=>$step5,'dropdowns'=>$new_outer_array,'defaultstiff'=>$mergestiffiner,'same_gage'=>$same_gage,'designConditionId'=>$designConditionId,'type'=>$type,'existDesignOptionFixed'=>$existDesignOptionFixed,'existDesignOptionUnfixed'=>$existDesignOptionUnfixed,'selectdefaultarr'=>$selectdefaultarr,'selected_stiffener_spacing'=>$selected_stiffener_spacing,'selected_stiffener_spacing_unfixed'=>$selected_stiffener_spacing_unfixed,'duct'=>$duct,'countcr'=>$countcr,'connecting_flange_dropdown'=>$connecting_fixed_dropdown,'connecting_unfixed_dropdown'=>$connecting_unfixed_dropdown,'mergestiffiner_unfixed'=>$mergestiffiner_unfixed,'selectdefaultarr_unfixed'=>$selectdefaultarr_unfixed,'new_outer_array_unfixed'=>$new_outer_array_unfixed,'nolayoutfixed'=>json_encode($designoptions_fixed)]);
				
			 }
		
			  return view('calculator/index',['particulates'=>$particulates,'classes'=>$classes,'insulationmaterial'=>$insulationmaterial,'laging'=>$lagingmaterial,'ductlinertype'=>$ductlinertype,'doublewallinner'=>$doublewallinner,'zonedata'=>$zoneData,'snowground'=>$snowData,'status'=>$status,'windData'=>$windData,'temperature'=>$temperature,'gage_number'=>$gage_number,'getMaterials'=>$getMaterials,'project_code'=>$projectcode,'project_id'=>$projectid,'exist'=>$exist,'crLoads'=>$crLoads,'dropdowns'=>$new_outer_array,'design'=>$designoptions,'designNoUnfixed'=>$designNoUnfixed,'des'=>$design,'step5'=>$step5,'designConditionId'=>$designConditionId,'type'=>$type,'duct'=>$duct,'countcr'=>$countcr]);
	
	}
	
	 /** 
		* author						: Ids Infotech Limited
		* function						: nextConnectingFlangeDrodown()
		* Purpose						: Its purpose to create an array of connecting flange dropdowns
		* description					: NA 
		* Argument						: It will take 2 parameter one is sizes and other is stiffener type 
		* created						: 16 May 2018
		* modified						: NA
	 */
	
	private function nextConnectingFlangeDrodown($getsizes=null,$stiffiner_type=null){
		$dropdown=array();
		
		foreach($getsizes as $key=>$sizes){
			$dropdown[$sizes->id.'-'.$sizes->stiffener_type_id]=$sizes->type.' '.$sizes->size.' '.$sizes->description;
		}
		
		return $dropdown;
	}
	
	 /** 
		* author						: Ids Infotech Limited
		* function						: nextSizeDrodown()
		* Purpose						: Its purpose to create an array of stiffeners dropdowns
		* description					: NA 
		* Argument						: It will take 2 parameter one is sizes and other is stiffener type 
		* created						: 16 May 2018
		* modified						: NA
	 */
	private function nextSizeDrodown($getsizes=null,$stiffiner_type=null){
		$dropdown=array();
		foreach($getsizes as $key=>$sizes){
			
			foreach($sizes as $key=>$sizes){
			$dropdown[$sizes->id.'-'.$sizes->stiffener_type_id]=$sizes->type.' '.$sizes->size.' '.$sizes->description;
			}
		}
		return $dropdown;
	}

 /** 
		* author						: Ids Infotech Limited
		* function						: unsetNAValue()
		* Purpose						: Its purpose to unset NA values from an array
		* description					: NA 
		* Argument						: $unsetNA is an array with NA values
		* created						: 16 May 2018
		* modified						: NA
	 */
	public function unsetNAValue($unsetNA=null){
		$retunWithoutarr=array();
		foreach($unsetNA as $na){
			if(!empty($na) && $na!='NA'){
				$retunWithoutarr[]=$na;
			}
			
		}
		return $retunWithoutarr;
	}
 
 /** 
		* author						: Ids Infotech Limited
		* function						: refineDesignOption()
		* Purpose						: Its purpose to unset NA values from an array
		* description					: Refine NA values of connecting flange from design options
		* Argument						: $unfixeddesignoption is an array with NA values
		* created						: 16 May 2018
		* modified						: NA
	 */

	public function refineDesignOption($unfixeddesignoption=null){
		
		$unsetUnfixed=array();
		foreach($unfixeddesignoption as $key=>$unfixed){
			if(count($unfixed['sides_arr'])>1){
				$unfixeddesignoption[$key]['connecting_flang']='NA';
			}
			
		}
		return $unfixeddesignoption;
		
		
		
	}

 /** 
		* author						: Ids Infotech Limited
		* function						: stiffenerDropdownNo()
		* Purpose						: Its purpose to create stiffenerdropdown with no layout
		* description					: 
		* Argument						: NA
		* created						: 16 May 2018
		* modified						: NA
	 */
	 
	 private function stiffenerDropdownNo($designoptions=null,$auxmaterialtype=null,$type=null){
						$dropdown=array();
						$stiffener_type_top=array_column($designoptions['toppanel'],'stiffiner_type');
						$stiffener_type_bottom=array_column($designoptions['bottompanel'],'stiffiner_type');
						$stiffener_type_side=array_column($designoptions['sidepanel'],'stiffiner_type');
						$mergestiffiner=array_unique(array_merge($stiffener_type_top,$stiffener_type_bottom,$stiffener_type_side));
						$mergestiffiner=array_values($mergestiffiner);
						$aux_stiffener_type_id_top=array_column($designoptions['toppanel'],'aux_stiffener_type_id');
						$aux_stiffener_type_id_bot=array_column($designoptions['bottompanel'],'aux_stiffener_type_id');
						$aux_stiffener_type_id_side=array_column($designoptions['sidepanel'],'aux_stiffener_type_id');
						$mergearr=array_merge($aux_stiffener_type_id_top,$aux_stiffener_type_id_bot,$aux_stiffener_type_id_side);
						$uniquestiffener=array_values(array_unique($mergearr));
						$uniquestiffener=$this->unsetNAValue($uniquestiffener);
						$mergestiffiner=$this->unsetNAValue($mergestiffiner);
						
						$dropdown=array();
						
						natsort($uniquestiffener);
						$uniquestiffener=array_values($uniquestiffener);
						natsort($mergestiffiner);
						$mergestiffiner=array_values($mergestiffiner);
						//$mergestiffiner=array_merge($mergestiffiner);
						$selectdefaultarr=array();
						$selectdefaultarrDeafult=array();
						
						$i=0;foreach($uniquestiffener as $ukey=>$unique){						
								$stiffersizeObj=Calculator::getDefaultSiffenerSize($auxmaterialtype,$unique,1);
								
								$sizeObj=Calculator::getSiffenerSize($auxmaterialtype,$unique)->toArray();
								$defaultsize=$stiffersizeObj->size.' '.$stiffersizeObj->description;
								
								 if(isset($type) && $type!='edit'){	
									 			
									$selectdefaultarrDeafult[]=$mergestiffiner[$i].' '.$defaultsize;
								 }else{//for default load and user when result were not saved and use it when edit case is load and has no data in DB
									 
									$selectdefaultarrDeafult[]=$mergestiffiner[$i].' '.$defaultsize;
								 }
								
								  
							foreach($sizeObj as $defkey1=>$default1){	
								$dropdown[$mergestiffiner[$i]][$default1->id.'-'. $default1->stiffener_type_id]=$mergestiffiner[$i].' '.$default1->size.' '.$default1->description;								
								$dropdown[$mergestiffiner[$i]][$default1->id.'-'. $default1->stiffener_type_id]=$mergestiffiner[$i].' '.$default1->size.' '.$default1->description;	
															
							}
							
						$i++;
						}
						
					$outer_array=array();
					$keys = array_keys($dropdown);
				
					foreach(array_keys($keys) as $k=>$val ){
						if(isset($keys[$k+2])){
							$this_value = $dropdown[$keys[$k]];
							
							$nextval = $dropdown[$keys[$k+1]];
							$nextnextval = $dropdown[$keys[$k+2]];
							$new=array_merge($this_value,$nextval,$nextnextval);
							$outer_array[$keys[$k]]=$new;
						}else{
							$current=substr($keys[$k],1);
							$getsizes=array();
							for($i=0 ;$i<3;$i++){
								
								$getCurrent=Calculator::getLeftPanelStiffenerDropdowns($auxmaterialtype,$current);
								if(empty($getCurrent)){
									$current=$current+1;
									$getCurrent=Calculator::getLeftPanelStiffenerDropdowns($auxmaterialtype,$current);
								}
								$current=$current+1;
								$getsizes[$i]=$getCurrent;
							}
							
							if(!empty($getsizes)){
								$nextdopdown=$this->nextSizeDrodown($getsizes,$keys[$k]);
								
								$outer_array[$keys[$k]]=$nextdopdown;
							}
						}
					}
								
					
					
					$new_outer_array=$this->getStiffinerDropdown($outer_array);	
					
					$returndropdown['mergestiffiner']=$mergestiffiner;
					$returndropdown['selectdefaultarr']=$selectdefaultarrDeafult;
					$returndropdown['new_outer_array']=$new_outer_array;
					
					return $returndropdown;
		 
		 
	 } 

	 /** 
		* author						: Ids Infotech Limited
		* function						: stiffenerDropdown()
		* Purpose						: Its pupose to create stiffener dropdowns for yes layout
		* description					: NA
		* Argument						: NA
		* created						: 16 May 2018
		* modified						: NA
	 */
	 
	 private function stiffenerDropdown($designoptions=null,$auxmaterialtype=null,$type=null){
						$dropdown=array();
						$stiffener_type_top=array_column($designoptions,'stiffener_type_top');
						$stiffener_type_bottom=array_column($designoptions,'stiffener_type_bottom');
						$stiffener_type_side=array_column($designoptions,'stiffener_type_side');
						
						$mergestiffiner=array_unique(array_merge($stiffener_type_top,$stiffener_type_bottom,$stiffener_type_side));
						
						$mergestiffiner=array_values($mergestiffiner);
						
						$aux_stiffener_type_id_top=array_column($designoptions,'aux_stiffener_type_id_top');
						$aux_stiffener_type_id_bot=array_column($designoptions,'aux_stiffener_type_id_bot');
						$aux_stiffener_type_id_side=array_column($designoptions,'aux_stiffener_type_id_side');					
						
						$mergearr=array_merge($aux_stiffener_type_id_top,$aux_stiffener_type_id_bot,$aux_stiffener_type_id_side);						
						
						$uniquestiffener=array_values(array_unique($mergearr));
						$uniquestiffener=$this->unsetNAValue($uniquestiffener);
						$mergestiffiner=$this->unsetNAValue($mergestiffiner);
						$dropdown=array();
						
						natsort($uniquestiffener);
						$uniquestiffener=array_values($uniquestiffener);
						
						natsort($mergestiffiner);

						$mergestiffiner=array_values($mergestiffiner);
						//$mergestiffiner=array_merge($mergestiffiner);
						

						$selectdefaultarr=array();
						$selectdefaultarrDeafult=array();
						
						$i=0;foreach($uniquestiffener as $ukey=>$unique){						
								$stiffersizeObj=Calculator::getDefaultSiffenerSize($auxmaterialtype,$unique,1);
								
								$sizeObj=Calculator::getSiffenerSize($auxmaterialtype,$unique)->toArray();
								$defaultsize=$stiffersizeObj->size.' '.$stiffersizeObj->description;
								
								 if(isset($type) && $type!='edit'){	
									 			
									$selectdefaultarrDeafult[]=$mergestiffiner[$i].' '.$defaultsize;
								 }else{//for default load and user when result were not saved and use it when edit case is load and has no data in DB
									 
									$selectdefaultarrDeafult[]=$mergestiffiner[$i].' '.$defaultsize;
								 }
								
								  
							foreach($sizeObj as $defkey1=>$default1){	
								$dropdown[$mergestiffiner[$i]][$default1->id.'-'. $default1->stiffener_type_id]=$mergestiffiner[$i].' '.$default1->size.' '.$default1->description;								
								$dropdown[$mergestiffiner[$i]][$default1->id.'-'. $default1->stiffener_type_id]=$mergestiffiner[$i].' '.$default1->size.' '.$default1->description;	
															
							}
							
						$i++;
						}
						
					$outer_array=array();
					$keys = array_keys($dropdown);
					//echo '<pre>';print_r($keys);die;
					foreach(array_keys($keys) as $k=>$val ){
						if(isset($keys[$k+2])){
							$this_value = $dropdown[$keys[$k]];
							
							$nextval = $dropdown[$keys[$k+1]];
							$nextnextval = $dropdown[$keys[$k+2]];
							$new=array_merge($this_value,$nextval,$nextnextval);
							$outer_array[$keys[$k]]=$new;
						}else{
							$current=substr($keys[$k],1);
							$getsizes=array();
							for($i=0 ;$i<3;$i++){
								
								
								$getCurrent=Calculator::getLeftPanelStiffenerDropdowns($auxmaterialtype,$current);
								
								if(empty($getCurrent)){
									$current=$current+1;
									$getCurrent=Calculator::getLeftPanelStiffenerDropdowns($auxmaterialtype,$current);
									
								}
								$current=$current+1;
								$getsizes[$i]=$getCurrent;
								
							}
								
							
							if(!empty($getsizes)){
								$nextdopdown=$this->nextSizeDrodown($getsizes,$keys[$k]);
								
								$outer_array[$keys[$k]]=$nextdopdown;
							}
						}
					}
					
					$new_outer_array=$this->getStiffinerDropdown($outer_array);	
								
					
					$returndropdown['mergestiffiner']=$mergestiffiner;
					$returndropdown['selectdefaultarr']=$selectdefaultarrDeafult;
					$returndropdown['new_outer_array']=$new_outer_array;
					
					return $returndropdown;
		 
		 
	 } 


	
		
				
	 /** 
		* author						: Ids Infotech Limited
		* function						: getUnstiffenedID()
		* Purpose						: This fucntion will be used to get unstiffened spacing id when stiffeners array not available  
		* description					: 
		* Argument						: NA
		* created						: 17 October 2018
		* modified						: NA
	 */
	
	private function getUnstiffenedID($postData,$stiffeners_spacing,$materialtype,$width_height){
		$unstiffenedObjArr=array();
		$unstiffened=array(0=>'0.0');
		$stiffenersObj = Calculator::getSpacingID($width_height,$materialtype,$unstiffened)->first();
		if(isset($stiffenersObj)){
			$unstiffenedArr=array('id'=>$stiffenersObj->id,'spacing'=>$stiffeners_spacing[0]);
			$unstiffenedObjArr[]=(object)$unstiffenedArr;
		}
		
		return $unstiffenedObjArr;
	}
	
	
		 /** 
		* author						: Ids Infotech Limited
		* function						: getTopCriticalLoad()
		* Purpose						: Its pupose to calculate critical loads for Top panel
		* description					: NA
		* Argument						: NA
		* created						: 16 May 2018
		* modified						: NA
	 */

private function getTopCriticalLoad($postData=null,$stiffener_type_id=null,$stifinersizeid=null,$stiffeners_spacing=null,$mingage=null,$maxgage=null,$min_max_array=null,$gagedropid=null,$gap_panel_id=null){
	
		try{
			$wss=WSS;
			$Wsd=0;
			$wsi=0;
			$wsc=0;
			$width=0;
			$Wp=0;
			$Pw=0;
			$Wice=!empty($postData['zone'])?$postData['zone']:0;
			$Wsnow=!empty($postData['snow_load'])?$postData['snow_load']:0;
			$lagingweight=0;
			$insweight=0;
			$topPanelArray=array();
			$sign=$postData['positive_negtive_pressure'];
			$designPressure=$postData['design_pressure'];
			$design_temperature=$postData['design_temperature'];
			$mat_class=$postData['mat-classes'];
			$Wsl=$this->zoneAndSnowCal($Wice,$Wsnow);
			$this->Wsl=$Wsl;
			$isinteresct=array();
			$unstiffenedDuctRelation=array();
			$check_unstiffened=array();
			$stiffeners_sameside=array();
			$countcombinedstiffiner=array();
			$topdesignoption=array();
			$check_unstiffened_comp=array();
			$ductmaterial=explode('-',$postData['duct_material']);
			$materialtype=$ductmaterial[0];
			$auxmaterialtype=$this->getMatterialMapping($materialtype);
			if(!empty($postData['ext_ins_type'])){
				$densityarray=Calculator::getInsDensity($postData['ext_ins_type']);
				$insweight=($densityarray->density/12)*$postData['ext_ins_thick']*LOADSTANDARD;
			}
			if(!empty($postData['laging_material']))
			{
				$lagingweight=$postData['laging_material'];
			}
			
			$Wp=$this->getParticulateWeight($postData);//Particulate weight calculation
			if(!empty($postData['wind_velocity'])){
				$windpressure=Calculator::getWindPressure($postData['wind_velocity']);	
				$Pw=$windpressure->wind_pressure_in;
			}
			$this->Wsd=$Wsd;
			if(!empty($postData['duct_height'])){
			$height=$postData['duct_height']/12;
			$height=ceil(number_format((float)$height,1, '.', ''));
				if($height>8){
					$height=9;
				}
			
			}
			if(!empty($postData['duct_width'])){
			$width=$postData['duct_width']/12;
			$actual_width=$postData['duct_width']/12;
			$width=ceil(number_format((float)$width,1, '.', ''));
			$actual_width=ceil(number_format((float)$actual_width,1, '.', ''));
			if($width>8){
				$width=9;
			}
							
			$actualpaneldata=$this->getActualPanelId($postData);
			$panelid_width=Calculator::getDuctPanelID($width,$materialtype);
			
			$stiffeners_width_stiff = Calculator::getStiffeners($panelid_width->id,$materialtype);
		
			$panelid_height=Calculator::getDuctPanelID($height,$materialtype);
						
			$stiffeners_height_stiff = Calculator::getStiffeners($panelid_height->id,$materialtype);
			
			
			$widthcount=count($stiffeners_width_stiff);
			$heightcount=count($stiffeners_height_stiff);
		
			$panelid=($width>=$height)?$panelid_width:$panelid_height;
			$panel_oposite=($width<$height)?$panelid_width:$panelid_height;
			$stiffeners_oposite = Calculator::getStiffeners($panel_oposite->id,$materialtype);
				
			$checkgage=array();
			if(!empty($stiffener_type_id) && !empty($stiffeners_spacing) && empty($gagedropid)){
				
				
				$spacing_id_array=array_column($stiffeners_spacing,'spacing_id');
				
				$selected_spacing_id_array=array_column($stiffeners_spacing,'selected_stiffener_type_id');
				$checkgage=array_column($stiffeners_spacing,'gagecheck');
				$stiffeners_spacing=array_column($stiffeners_spacing,'spacing');
				$stiffeners = $this->convertToObjectArray($stiffeners_spacing,$spacing_id_array);
				
				
			}else if(!empty($mingage)&&!empty($maxgage)){//&& !isset($postData['yesunfixed'])
					
					$stiffiner_type_id_primary=array_column($stiffeners_spacing,'stiffiner_type_id');
					$spacing_id_array=array_column($stiffeners_spacing,'spacing_id');
					$stiffeners_spacing=array_column($stiffeners_spacing,'spacing');
				$stiffeners = $this->convertToObjectArray($stiffeners_spacing,$spacing_id_array);
				
			}else if(!empty($gagedropid)){
				
				
				if(!empty($gap_panel_id)){
					if(isset($postData['stiffiner_comparision'])&&$postData['stiffiner_comparision']==1){
						$postData['actualstiffiner']=$stiffeners_spacing;
					}
				$stiffeners = Calculator::getSpacingID($gap_panel_id,$materialtype,$stiffeners_spacing);
				
			
				if(count($stiffeners)<1){
					$stiffeners_spacing=array(0=>'0.0');
					$stiffeners = Calculator::getSpacingID($gap_panel_id,$materialtype,$stiffeners_spacing);
						
				}
						
				}else{
				    if(isset($postData['nounfixedlayout']) && $postData['nounfixedlayout']==1){
						$stiffeners = Calculator::getSpacingID($actualpaneldata['height_id'],$materialtype,$stiffeners_spacing);
					}else{
						$stiffeners = Calculator::getSpacingID($actualpaneldata['width_id'],$materialtype,$stiffeners_spacing);
					}
					
				//	echo '<pre>';print_r($stiffeners);die;
					if(count($stiffeners)<1){

						$stiffeners=$this->getUnstiffenedID($postData,$stiffeners_spacing,$materialtype,$actualpaneldata['width_id']);

					}
					
				}
				
				
			}else if(isset($postData['unfixed_flag']) && $postData['unfixed_flag']==1 && $postData['same_gage']=="No"){
				
				if(isset($postData['bending']) && $postData['bending']=='bending'){
									
					$stiffeners = Calculator::getSpacingID($panelid_width->id,$materialtype,$postData['stiffeners_spacing']);
				
				}else{
					$stiffeners = Calculator::getStiffeners($panelid_width->id,$materialtype);
				}
				
				
			}else{
				if($width!=$height){
					
					$check_unstiffened_comp =json_decode(json_encode($stiffeners_oposite), true);
					$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
					$stiffeners_sameside = Calculator::getStiffeners($panelid->id,$materialtype);
					$stiffeners_sameside=$this->checkUnstiffenedExist($stiffeners_sameside);
						
					if(!empty($check_unstiffened)){// && empty($stiffeners_sameside)
						$unstiffenedDuctRelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$panel_oposite->id,$check_unstiffened['id']);
						$stiffeners = Calculator::getStiffeners($panelid->id,$materialtype);
						
						$width_stiffiner =json_decode(json_encode($stiffeners), true);
						$countcombinedstiffiner=count($width_stiffiner);
						$isinteresct=array_intersect(array_column($width_stiffiner,'spacing'),array_column($check_unstiffened_comp,'spacing'));
						
						
					}else{
						
						$commone_spacing=$this->getCommonStiffener($postData);
						$stiffeners = Calculator::getSpacingID($panelid->id,$materialtype,$commone_spacing);
						
					}
					
				}else{
					
						$commone_spacing=$this->getCommonStiffener($postData);
						$stiffeners = Calculator::getSpacingID($panelid->id,$materialtype,$commone_spacing);
					
					
				}
				
			}
			
			
			$width=($postData['vertical_horigental']=='Vertical')?$height:$width;
			$actual_width=($postData['vertical_horigental']=='Vertical')?$height:$actual_width;
			$array = json_decode(json_encode($stiffeners), true);
			$stiffenersids = array_column($array, 'id');
			$topPanel=array();	
			$topauxarray=array();
			$paneweightcom=0;
			
							
							
			
			foreach($stiffeners as $key=>$stiff)
			{
							
				
				$Wsd=0;
				$wss=0;
				$ductspacingid=$stiff->id;
					if($actualpaneldata['width']<$actualpaneldata['height'] && !isset($postData['left_panel'])){	
						if(!empty($check_unstiffened)){
							$ductspacingid=$this->getDuctSpacingId($check_unstiffened,$check_unstiffened_comp,$stiff->spacing);
						}
					}
						
							
			if(!empty($mingage) && !empty($maxgage)){
				$exp1=explode('_',$mingage);
				
				$mingage=$exp1[0];
				$mingagethkiness=isset($exp1[1])?$exp1[1]:'';
				$exp2=explode('_',$maxgage);
				$maxgage=$exp2[0];
				$maxgagethickness=isset($exp2[1])?$exp2[1]:'';
				$mingageObj=Calculator::getGageID($materialtype,$mingage);
				$maxgageObj=Calculator::getGageID($materialtype,$maxgage);
				$mingageid=$mingageObj->id;
				$maxgageid=$maxgageObj->id;
				$getAllgageObj=Calculator::getAllGageId($materialtype,$mingageid,$maxgageid);
				//echo '<pre>';print_r($stiffeners);die;
				$allgageid=array_column(json_decode($getAllgageObj,true),'id');
				$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
				
				
				$ductspacingid=isset($spacing_id_array[$key])?$spacing_id_array[$key]:$check_unstiffened['id'];
				$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$allgageid);
								
				
			}else if(!empty($gagedropid)&& empty($gap_panel_id)){
					
				$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
				if(isset($postData['middle_fixed_yes'])&& ($width!=$height) && !empty($check_unstiffened)){
					
					$ductspacingid=isset($postData['stiffSpacingId'][0])?$postData['stiffSpacingId'][0]:$check_unstiffened['id'];
					
					if(isset($postData['nounfixedlayout']) && $postData['nounfixedlayout']==1){
						$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid,$gagedropid);
					}else{
					//echo '<pre>'; print_r($postData);exit;
						$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$gagedropid);
						//echo '<pre>';print_r($topPanelArray);die;
					}

				}else{
					
					
					$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$gagedropid);

				}
					
				$mingageObj=Calculator::getGageID($materialtype,$mingage);
				
					
			}
			else if(!empty($checkgage)){
				
					$ductspacingid=isset($spacing_id_array[$key])?$spacing_id_array[$key]:$check_unstiffened['id'];
					$check=explode('_',$checkgage[$key]);
					$getgageid=Calculator::getGageID($materialtype,$check[1]);
					$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$getgageid->id);
					
				
			}else{
				
					$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid);
					
					
					
			}
				
				if(count($ductrelation)>0){
					$Wsd=$insweight+$lagingweight;	
							
							
				$topPanelArray=$this->process($key,$ductrelation,$width,$paneweightcom,$Wsd,$Wsl,$wss,$sign,$designPressure,'Top',$Wp,$Pw,$postData,$stiff);// Process One Calculation
					
							
				if($topPanelArray){
							
					if(!empty($topPanelArray['id'])){
						$topPanelCr=isset($topPanelArray['critical_load'])?$topPanelArray['critical_load']:0;
						if($stiff->spacing!=0.00){
							$newvar=$this->getReinforcementCalculation($actual_width,$stiff->spacing,$auxmaterialtype,$topPanelCr,$key,null,$postData);
						}
						
						
						if(!empty($stifinersizeid)){
							
							
							$typeid=$stifinersizeid;
							$postData['typeid']=isset($selected_spacing_id_array)?$selected_spacing_id_array[$key]:'';
							$defaultflag=0;
						}else if($min_max_array){
							
							$typeid=$min_max_array[$key]['stifiner_size_primary_key'];
							$defaultflag=0;
							
						}else if(!empty($mingage) && !empty($maxgage) && !empty($min_max_array)){
							
							$typeid=$stiffiner_type_id_primary[$key];
							$defaultflag=0;
							$postData['typeid']=$typeid;
							$stiffener_type_id=$typeid;
						
						}else{
							
							$defaultflag=1;
							$typeid=isset($newvar->aux_stiffener_type_id)?$newvar->aux_stiffener_type_id:'';
							$stiffener_type_id=$typeid;
						}
						
						if($stiff->spacing!=0.00){
							if($postData['transverse']=='Connecting Flanges'){
								
								$connectinflangeDefaultSize=Calculator::getConnectingDefaultSiffenerSize($auxmaterialtype,$stiffener_type_id,1);
								
								$connectingFlangearr=[];
								$connectingFlangearr['duct_length']=isset($postData['duct_length'])?$postData['duct_length']:4;
								$connectingFlangearr['connectingFlangeQualify']=isset($postData['connectingFlangeQualify'])?$postData['connectingFlangeQualify']:1;
								$connectingFlangearr['stiffiner_spacing']=$stiff->spacing;
								
								$connectingFlangearr['stiffener_type_id']=$stiffener_type_id;
								$connectingFlangearr['stiffener_type']='R'.$stiffener_type_id;
								$connectingFlangearr['primary_stiffener_type_id']=$connectinflangeDefaultSize->id;
								
								$wss=$this->connectingFlangeDoCount($connectingFlangearr,$auxmaterialtype);
								
								
							}else{
								$wss=$this->getStiffinerLoad($auxmaterialtype,$typeid,$defaultflag,$stiff->spacing);
							}
							
						}
							
						$Wsd=0;
						$Wsd=$insweight+$lagingweight;	
							
						$paneweightcom=$designPressure;
						
						$topPanelArray=$this->process($key,$ductrelation,$width,$paneweightcom,$Wsd,$Wsl,$wss,$sign,$designPressure,'Top',$Wp,$Pw,$postData,$stiff);
							
							$retrackstiffinertype=array();
						if($stiff->spacing!=0.00){
							$retrackstiffinertype=$this->getReinforcementCalculation($actual_width,$stiff->spacing,$auxmaterialtype,$topPanelArray['critical_load'],null,null,$postData);// Second Time  capacity calculation
						}
								
								$topdesignoption=$this->getAuxiliaryArray($retrackstiffinertype,$topPanelArray,$wss,$design_temperature,$auxmaterialtype,$ductspacingid,$postData);
							
						
						
					}else{
								
							$topdesignoption['critical_load'] =$topPanelArray['critical_load'];
							$topdesignoption['aux_stiffener_type_id'] =0;
							$topdesignoption['stiffiner_spacing'] =$stiff->spacing;
							$topdesignoption['spacing_id'] = $stiff->id;
							$topdesignoption['stiffiner_type'] = 0;
							$topdesignoption['stiffiner_load'] = 0;
							$topdesignoption['stiffiner_capacity'] = 0;
							$topdesignoption['stiffiner_capacity_unfixed'] = 0;
							$topdesignoption['panel_pressure'] = 0;
							$topdesignoption['panel_deflection'] =0;
							$topdesignoption['panel_gage_number'] =0;
							$topdesignoption['panel_weight'] =0;
							$topdesignoption['thickness'] =0;
							$topdesignoption['material_thickness_id'] =0;
							$topdesignoption['duct_material_gage_id'] =0;
							$topdesignoption['stifiner_load'] =0;
							
					}
								
					
						$topPanel[$key]=$topdesignoption;
					//}
				}
				
			}
										
				
		}
		
		
	}
				
	if($countcombinedstiffiner!=$widthcount){
		
		$topPanel=$this->mappingOnUnstiffined($topPanel,$unstiffenedDuctRelation,$isinteresct,$materialtype,$mat_class,$design_temperature,$panel_oposite->id,$check_unstiffened);
		
	}
						
	
			
		
		
	return $topPanel;
	}catch(Exception $e){	
								
		echo $e->getMessage();
	}

}



	
	
	
	 /** 
		* author						: Ids Infotech Limited
		* function						: getBottomCriticalLoad()
		* Purpose						: Its pupose to calculate critical loads for Bottom Panel
		* description					: NA
		* Argument						: NA
		* created						: 16 May 2018
		* modified						: NA
	 */
	
	private function getBottomCriticalLoad($postData=null,$stiffener_type_id=null,$stifinersizeid=null,$stiffeners_spacing=null,$mingage=null,$maxgage=null,$min_max_array=null,$gagedropid=null,$gap_panel_id=null){
		try{
			
		$wss=WSS;
		$Wsd=0;
		$wsi=0;
		$wsc=0;
		$Wice=!empty($postData['zone'])?$postData['zone']:0;
		$Wsnow=!empty($postData['snow_load'])?$postData['snow_load']:0;
		$Wp=0;
		$Pw=0;
		$lagingweight=0;
		$insweight=0;
		$isinteresct=array();
		$unstiffenedDuctRelation=array();
		$check_unstiffened=array();
		$stiffeners_sameside=array();
		$sign=$postData['positive_negtive_pressure'];
		$designPressure=$postData['design_pressure'];
		$design_temperature=$postData['design_temperature'];
		$mat_class=$postData['mat-classes'];
		$topdesignoption=array();
		$bottomPanelArray=array();
		$countcombinedstiffiner=array();
		$botomPanel=array();
		$Wsl=$this->zoneAndSnowCal($Wice,$Wsnow);
		$Wsl=$Wice+$Wsnow;
		$ductmaterial=explode('-',$postData['duct_material']);
		$materialtype=$ductmaterial[0];
		$auxmaterialtype=$this->getMatterialMapping($materialtype);
		if(!empty($postData['ext_ins_type'])){
			$densityarray=Calculator::getInsDensity($postData['ext_ins_type']);
			$insweight=($densityarray->density/12)*$postData['ext_ins_thick']*LOADSTANDARD;
		}
		if(!empty($postData['laging_material'])){
			
			$lagingweight=$postData['laging_material'];
		}
		
			$Wp=$this->getParticulateWeight($postData);//Particulate weight calculation
			if(!empty($postData['wind_velocity'])){
				$windpressure=Calculator::getWindPressure($postData['wind_velocity']);	
				$Pw=$windpressure->wind_pressure_in;
			}
		
		$Wsd=number_format($wss+$insweight+$lagingweight,2);
		
		$toppanel='';
		$bottompanel='';
		
		$width=0;
		if(!empty($postData['duct_width'])){
			
			if(!empty($postData['duct_height'])){
				$height=$postData['duct_height']/12;
					if($height>8){
						$height=9;
					}
				$height=ceil(number_format((float)$height,1, '.', ''));
			}
				
			if(!empty($postData['particulate_material_id'])&&$postData['particulate_material_id']!='None'){
			
				$depth=($postData['percentage_full']/100)*$height;
				$Wp=round($depth*$postData['perticulate_density']*PARTICULATEDENCONST,2);
			}
			
			$width=$postData['duct_width']/12;
			$actual_width=$postData['duct_width']/12;
			
			if($width>8){
				$width=9;
				
			}
			
			$actualpaneldata=$this->getActualPanelId($postData);
			$width=ceil(number_format((float)$width,1, '.', ''));
			$actual_width=ceil(number_format((float)$actual_width,1, '.', ''));
			
				$panelid_width=Calculator::getDuctPanelID($width,$materialtype);
				
				$stiffeners_width_stiff = Calculator::getStiffeners($panelid_width->id,$materialtype);
			
				$panelid_height=Calculator::getDuctPanelID($height,$materialtype);
				
				
				$stiffeners_height_stiff = Calculator::getStiffeners($panelid_height->id,$materialtype);
				
				
				$widthcount=count($stiffeners_width_stiff);
				$heightcount=count($stiffeners_height_stiff);
				
				
				
				$panelid=($width>=$height)?$panelid_width:$panelid_height;
				$panel_oposite=($width<$height)?$panelid_width:$panelid_height;
				$stiffeners_oposite = Calculator::getStiffeners($panel_oposite->id,$materialtype);
			
			
			
			
			
			if(!empty($stiffener_type_id) && !empty($stiffeners_spacing) && empty($gagedropid)){
				
				$spacing_id_array=array_column($stiffeners_spacing,'spacing_id');
				$checkgage=array_column($stiffeners_spacing,'gagecheck');
				$selected_spacing_id_array=array_column($stiffeners_spacing,'selected_stiffener_type_id');
				//$stiffeners_spacing=array_column($stiffeners_spacing,'stiffiner_spacing');
				$stiffeners_spacing=array_column($stiffeners_spacing,'spacing');
				$stiffeners = $this->convertToObjectArray($stiffeners_spacing,$spacing_id_array);
				
				
			}else if(!empty($mingage)&&!empty($maxgage)){
				
				$stiffiner_type_id_primary=array_column($stiffeners_spacing,'stiffiner_type_id');
				$spacing_id_array=array_column($stiffeners_spacing,'spacing_id');
				$stiffeners_spacing=array_column($stiffeners_spacing,'spacing');
				$stiffeners = $this->convertToObjectArray($stiffeners_spacing,$spacing_id_array);
				
			
				
			}else if(!empty($gagedropid)){
				
				
				if(!empty($gap_panel_id)){
					if(isset($postData['stiffiner_comparision'])&&$postData['stiffiner_comparision']==1){
						$postData['actualstiffiner']=$stiffeners_spacing;
					}
					$stiffeners = Calculator::getSpacingID($gap_panel_id,$materialtype,$stiffeners_spacing);
				if(count($stiffeners)<1){
					$stiffeners_spacing=array(0=>'0.0');
					$stiffeners = Calculator::getSpacingID($gap_panel_id,$materialtype,$stiffeners_spacing);
						
				}
				
				}else{
					
					if(isset($postData['nounfixedlayout']) && $postData['nounfixedlayout']==1){
						$stiffeners = Calculator::getSpacingID($actualpaneldata['height_id'],$materialtype,$stiffeners_spacing);
					}else{
						$stiffeners = Calculator::getSpacingID($actualpaneldata['width_id'],$materialtype,$stiffeners_spacing);
						if(count($stiffeners)<1){
						$stiffeners=$this->getUnstiffenedID($postData,$stiffeners_spacing,$materialtype,$actualpaneldata['width_id']);
						}
						
					}
					
				//	echo '<pre>';print_r($stiffeners);exit;
					
				}
				
				
			}else if(isset($postData['unfixed_flag']) && $postData['unfixed_flag']==1 && $postData['same_gage']=="No"){
				
				if(isset($postData['bending']) && $postData['bending']=='bending'){
									
					$stiffeners = Calculator::getSpacingID($panelid_width->id,$materialtype,$postData['stiffeners_spacing']);
				
				}else{
					$stiffeners = Calculator::getStiffeners($panelid_width->id,$materialtype);
				}
				
				
			}else{
				$commonstiffener=$this->getCommonStiffener($postData);
				
					if($width!=$height){
						
						
							$check_unstiffened_comp =json_decode(json_encode($stiffeners_oposite), true);
							$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
							$stiffeners_sameside = Calculator::getStiffeners($panelid->id,$materialtype);
							$stiffeners_sameside=$this->checkUnstiffenedExist($stiffeners_sameside);
					
							if(!empty($check_unstiffened)){//&&empty($stiffeners_sameside)
								$unstiffenedDuctRelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$panel_oposite->id,$check_unstiffened['id']);
								$stiffeners = Calculator::getStiffeners($panelid->id,$materialtype);
								
								$width_stiffiner =json_decode(json_encode($stiffeners), true);
								$countcombinedstiffiner=count($width_stiffiner);
								$isinteresct=array_intersect(array_column($width_stiffiner,'spacing'),array_column($check_unstiffened_comp,'spacing'));
							}else{
								$commone_spacing=$this->getCommonStiffener($postData);
								$stiffeners = Calculator::getSpacingID($panelid->id,$materialtype,$commone_spacing);
								
							}
					}else{
							
								$commone_spacing=$this->getCommonStiffener($postData);
								$stiffeners = Calculator::getSpacingID($panelid->id,$materialtype,$commone_spacing);
							
						}		
				}
			$width=($postData['vertical_horigental']=='Vertical')?$height:$width;
			$actual_width=($postData['vertical_horigental']=='Vertical')?$height:$actual_width;
			$array = json_decode(json_encode($stiffeners), true);
			$stiffenersids = array_column($array, 'id');
			
			
			
			foreach($stiffeners as $key=>$stiff){
				$Wsd=0;
				$wss=0;
				$ductspacingid=$stiff->id;
				$paneweightcom=round($postData['design_pressure'],2);
					if($actualpaneldata['width']<$actualpaneldata['height'] && !isset($postData['left_panel'])){	
						if(!empty($check_unstiffened)){
							$ductspacingid=$this->getDuctSpacingId($check_unstiffened,$check_unstiffened_comp,$stiff->spacing);
						}
					}
				
				
				if(!empty($mingage) && !empty($maxgage)){
					$exp1=explode('_',$mingage);
					$mingage=$exp1[0];
					$mingagethkiness=isset($exp1[1])?$exp1[1]:'';
					$exp2=explode('_',$maxgage);
					$maxgage=$exp2[0];
					$maxgagethickness=isset($exp2[1])?$exp2[1]:'';
					$mingageObj=Calculator::getGageID($materialtype,$mingage);
					$maxgageObj=Calculator::getGageID($materialtype,$maxgage);
					$mingageid=$mingageObj->id;
					$maxgageid=$maxgageObj->id;
					$getAllgageObj=Calculator::getAllGageId($materialtype,$mingageid,$maxgageid);
					$allgageid=array_column(json_decode($getAllgageObj,true),'id');
					$ductspacingid=isset($spacing_id_array[$key])?$spacing_id_array[$key]:$check_unstiffened['id'];
					$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$allgageid);
				
				}else if(!empty($gagedropid) && empty($gap_panel_id)){
					
					
							$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
							if(isset($postData['middle_fixed_yes'])&& ($width!=$height) && !empty($check_unstiffened)){
								$ductspacingid=isset($postData['stiffSpacingId'][1])?$postData['stiffSpacingId'][1]:$postData['stiffSpacingId'][0];
								
							if(isset($postData['nounfixedlayout']) && $postData['nounfixedlayout']==1){
								$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid,$gagedropid);
							}else{
								$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$gagedropid);
							}
							}else{
								$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$gagedropid);

							}
					
					
				}else if(!empty($checkgage)){
					
					$ductspacingid=isset($spacing_id_array[$key])?$spacing_id_array[$key]:$check_unstiffened['id'];
					$check=explode('_',$checkgage[$key]);
					$getgageid=Calculator::getGageID($materialtype,$check[1]);
					$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid,$getgageid->id);
					
				}else{
						
					
					$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['width_id'],$ductspacingid);
						
					
				}
				
				
				if(count($ductrelation)>0){

					$Wsd=$insweight+$lagingweight;	
					$bottomPanelArray=$this->process($key,$ductrelation,$width,$paneweightcom,$Wsd,$Wsl,$wss,$sign,$designPressure,'Bottom',$Wp,$Pw,$postData,$stiff);
					
					if($bottomPanelArray){
						//Start Recalculation
						
								
								if(!empty($bottomPanelArray['id'])){
									$bottomPanelArray=isset($bottomPanelArray['critical_load'])?$bottomPanelArray['critical_load']:0;
									if($stiff->spacing!=0.00){
										$newvar=$this->getReinforcementCalculation($actual_width,$stiff->spacing,$auxmaterialtype,$bottomPanelArray,$key,null,$postData);
									}
									
									
								
								if(!empty($stifinersizeid)){
									$typeid=$stifinersizeid;
									$postData['typeid']=isset($selected_spacing_id_array)?$selected_spacing_id_array[$key]:'';
									$defaultflag=0;
								}else if($min_max_array){
									$typeid=$min_max_array[$key]['stifiner_size_primary_key'];
									$defaultflag=0;
								}else if(!empty($mingage) && !empty($maxgage) && !isset($postData['fixedLayoutReinforcement'])){
									
									$typeid=$stiffiner_type_id_primary[$key];
									$defaultflag=0;
									$postData['typeid']=$typeid;
									$stiffener_type_id=$typeid;
								}else{
									$defaultflag=1;
									$typeid=isset($newvar->aux_stiffener_type_id)?$newvar->aux_stiffener_type_id:'';
									$stiffener_type_id=$typeid;
								}
								if($stiff->spacing!=0.00){
									if($postData['transverse']=='Connecting Flanges'){
										$connectinflangeDefaultSize=Calculator::getConnectingDefaultSiffenerSize($auxmaterialtype,$stiffener_type_id,1);
										$connectingFlangearr=[];
										$connectingFlangearr['duct_length']=isset($postData['duct_length'])?$postData['duct_length']:4;
										$connectingFlangearr['connectingFlangeQualify']=isset($postData['connectingFlangeQualify'])?$postData['connectingFlangeQualify']:1;
										$connectingFlangearr['stiffiner_spacing']=$stiff->spacing;
										
										$connectingFlangearr['stiffener_type_id']=$stiffener_type_id;
										$connectingFlangearr['stiffener_type']='R'.$stiffener_type_id;
										$connectingFlangearr['primary_stiffener_type_id']=$connectinflangeDefaultSize->id;
										$wss=$this->connectingFlangeDoCount($connectingFlangearr,$auxmaterialtype);
										
									}else{
										$wss=$this->getStiffinerLoad($auxmaterialtype,$stiffener_type_id,$defaultflag,$stiff->spacing);
									}
							
								}
								
								$Wsd=0;
								$Wsd=$insweight+$lagingweight;	
								
								$paneweightcom=$designPressure;
								
								$bottomPanelArray=$this->process($key,$ductrelation,$width,$paneweightcom,$Wsd,$Wsl,$wss,$sign,$designPressure,'Bottom',$Wp,$Pw,$postData,$stiff);
								$retrackstiffinertype=array();
								if($stiff->spacing!=0.00){
									$retrackstiffinertype=$this->getReinforcementCalculation($actual_width,$stiff->spacing,$auxmaterialtype,$bottomPanelArray['critical_load'],null,null,$postData);// Second Time  capacity calculation
								}
								
								
								
								$bottomdesignoption=$this->getAuxiliaryArray($retrackstiffinertype,$bottomPanelArray,$wss,$design_temperature,$auxmaterialtype,$ductspacingid,$postData);
									
								
							
								
							
								//END RENFORCEMENT CALCULATION
								
								}else{
									$bottomdesignoption['critical_load'] =0;
									$bottomdesignoption['aux_stiffener_type_id'] =0;
									$bottomdesignoption['stiffiner_spacing'] =$stiff->spacing;
									$bottomdesignoption['spacing_id'] = 0;
									$bottomdesignoption['stiffiner_type'] = 0;
									$bottomdesignoption['stiffiner_load'] = 0;
									$bottomdesignoption['stiffiner_capacity'] = 0;
									$bottomdesignoption['stiffiner_capacity_unfixed'] = 0;
									$bottomdesignoption['panel_pressure'] = 0;
									$bottomdesignoption['panel_deflection'] =0;
									$bottomdesignoption['panel_gage_number'] =0;
									$bottomdesignoption['panel_weight'] =0;
									$bottomdesignoption['thickness'] =0;
									$bottomdesignoption['material_thickness_id'] =0;
									$bottomdesignoption['duct_material_gage_id'] =0;
									$bottomdesignoption['stifiner_load'] =0;
								}
								
								$botomPanel[$key]=isset($bottomdesignoption)?$bottomdesignoption:'';
								
								
												
				}					
				}	
				
				}
				
		}
		
		if($countcombinedstiffiner!=$widthcount){
			$botomPanel=$this->mappingOnUnstiffined($botomPanel,$unstiffenedDuctRelation,$isinteresct,$materialtype,$mat_class,$design_temperature,$panel_oposite->id,$check_unstiffened);
		
		}
		
		return $botomPanel;
		}catch(Exception $e){
		
			echo $e->getMessage();	
		
		}
		
							
		
	}
	
	
	
	
	private function getDuctSpacingId($check_unstiffened=null,$check_unstiffened_comp=null,$spacing=null){
		$ductspacingid='';
		if(!empty($check_unstiffened)){
			if(in_array($spacing,array_column($check_unstiffened_comp,'spacing'))){
				
				foreach($check_unstiffened_comp as $matchingData){
					if($spacing==$matchingData['spacing']){
						$ductspacingid=$matchingData['id'];
					}
				}
				
			}else{
				
				$ductspacingid=$check_unstiffened['id'];
				
			}
		}
		
		return $ductspacingid;
	}
	
	
	 /** 
		* author						: Ids Infotech Limited
		* function						: getSidePanelCriticalLoad()
		* Purpose						: Its pupose to calculate critical loads for side panels
		* description					: 
		* Argument						: NA
		* created						: 16 May 2018
		* modified						: NA
	 */

	private function getSidePanelCriticalLoad($postData=null,$stiffener_type_id=null,$stifinersizeid=null,$stiffeners_spacing=null,$mingage=null,$maxgage=null,$min_max_array=null,$gagedropid=null,$gap_panel_id=null){
		try{
			
			$wss=WSS;
			$Wsd=0;
			$wsi=0;
			$wsc=0;
			$width=0;
			$Wp=0;
			$Pw=0;
			$Wice=!empty($postData['zone'])?$postData['zone']:0;
			$Wsnow=!empty($postData['snow_load'])?$postData['snow_load']:0;
			$lagingweight=0;
			$insweight=0;
			$topPanelArray=array();
			$sidePanel=array();
			$isinteresct=array();
			$unstiffenedDuctRelation=array();
			$countcombinedstiffiner=array();
			$check_unstiffened=array();
			$stiffeners_sameside=array();
			$topdesignoption=array();
			$sign=$postData['positive_negtive_pressure'];
			$designPressure=$postData['design_pressure'];
			$design_temperature=$postData['design_temperature'];
			$mat_class=$postData['mat-classes'];
			$ductmaterial=explode('-',$postData['duct_material']);
			$materialtype=$ductmaterial[0];
			$Wsl=$Wice+$Wsnow;
			$Wsl=$this->zoneAndSnowCal($Wice,$Wsnow);// Zone and Snow Calculation
			$this->Wsl=$Wsl;
			$Wp=$this->getParticulateWeight($postData);//Particulate weight calculation
			
			
		/* Wind load,Pw=based on a design wind velocity of 80 MPH find load in table B-1 page 415 ,80 MPH equivalent to 3.1 in.wg
		 For now i am taking it zero */
			$auxmaterialtype=$this->getMatterialMapping($materialtype);// Duct Material Mapping with Auxiliary Material
			$sidePanelArray=array();
			$sidedesignoption=array();
			$lagingweight=0;
			$insweight=0;
			if(!empty($postData['ext_ins_type'])){
				$densityarray=Calculator::getInsDensity($postData['ext_ins_type']);
				$insweight=($densityarray->density/12)*$postData['ext_ins_thick']*LOADSTANDARD;
			}
			if(!empty($postData['laging_material'])){
				$lagingweight=$postData['laging_material'];
			}
			$Wsd=$wss+$insweight+$lagingweight;
			if(!empty($postData['wind_velocity'])){
				$windpressure=Calculator::getWindPressure($postData['wind_velocity']);	
				$Pw=$windpressure->wind_pressure_in;
			}
		
		if(!empty($postData['duct_height'])){
			$height=$postData['duct_height']/12;
			$height=ceil(number_format((float)$height,1, '.', ''));
			$actual_height=$postData['duct_height']/12;
			$actual_height=ceil(number_format((float)$actual_height,1, '.', ''));
			if($height>8){
				$height=9;
			}
			if(!empty($postData['duct_width'])){
				$width=$postData['duct_width']/12;
				$width=ceil(number_format((float)$width,1, '.', ''));
					if($width>8){
						$width=9;
					}
				
			}
				
				$actualpaneldata=$this->getActualPanelId($postData);
				$panelid_width=Calculator::getDuctPanelID($width,$materialtype);
				
				$stiffeners_width_stiff = Calculator::getStiffeners($panelid_width->id,$materialtype);
			
				$panelid_height=Calculator::getDuctPanelID($height,$materialtype);
				
				
				$stiffeners_height_stiff = Calculator::getStiffeners($panelid_height->id,$materialtype);
				//echo '<pre>';print_r($stiffeners_height_stiff);die;
				
				$widthcount=count($stiffeners_width_stiff);
				$heightcount=count($stiffeners_height_stiff);
				$panelid=($width>=$height)?$panelid_width:$panelid_height;
				
				$panel_oposite=($width<$height)?$panelid_width:$panelid_height;
				$stiffeners_oposite = Calculator::getStiffeners($panel_oposite->id,$materialtype);
				$check_unstiffened_comp =json_decode(json_encode($stiffeners_oposite), true);
			
			if(!empty($stiffener_type_id) && !empty($stiffeners_spacing) && empty($gagedropid)){
				$selected_spacing_id_array=array_column($stiffeners_spacing,'selected_stiffener_type_id');
				$spacing_id_array=array_column($stiffeners_spacing,'spacing_id');
				$checkgage=array_column($stiffeners_spacing,'gagecheck');
				$stiffeners_spacing=array_column($stiffeners_spacing,'spacing');
				$stiffeners = $this->convertToObjectArray($stiffeners_spacing,$spacing_id_array);
				
			}else if(!empty($mingage)&&!empty($maxgage)){
				
				$stiffiner_type_id_primary=array_column($stiffeners_spacing,'stiffiner_type_id');
				$spacing_id_array=array_column($stiffeners_spacing,'spacing_id');
				$stiffeners_spacing=array_column($stiffeners_spacing,'spacing');
				
				$stiffeners = $this->convertToObjectArray($stiffeners_spacing,$spacing_id_array);
				
				
				
			}else if(!empty($gagedropid)){
			
				if(!empty($gap_panel_id)){
					if(isset($postData['stiffiner_comparision'])&&$postData['stiffiner_comparision']==1){
						$postData['actualstiffiner']=$stiffeners_spacing;
					}
				$stiffeners = Calculator::getSpacingID($gap_panel_id,$materialtype,$stiffeners_spacing);
				
				if(count($stiffeners)<1){
					$stiffeners_spacing=array(0=>'0.0');
					$stiffeners = Calculator::getSpacingID($gap_panel_id,$materialtype,$stiffeners_spacing);
						
				}
				
				}else{
				
					$stiffeners = Calculator::getSpacingID($actualpaneldata['height_id'],$materialtype,$stiffeners_spacing);
					if(count($stiffeners)<1){
						$stiffeners=$this->getUnstiffenedID($postData,$stiffeners_spacing,$materialtype,$actualpaneldata['height_id']);
					}
				}
				
				
				
			}else if(isset($postData['unfixed_flag']) && $postData['unfixed_flag']==1 && $postData['same_gage']=="No"){
				
				
				
				if(isset($postData['bending']) && $postData['bending']=='bending'){
									
					$stiffeners = Calculator::getSpacingID($panelid_height->id,$materialtype,$postData['stiffeners_spacing']);
				
				}else{
					$stiffeners = Calculator::getStiffeners($panelid_height->id,$materialtype);
				}
				
				
			}else{
				
				if($width!=$height){
					
					$check_unstiffened_comp =json_decode(json_encode($stiffeners_oposite), true);
					
					$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
					$stiffeners_sameside = Calculator::getStiffeners($panelid->id,$materialtype);
					$stiffeners_sameside=$this->checkUnstiffenedExist($stiffeners_sameside);
					
					if(!empty($check_unstiffened)){//&&empty($stiffeners_sameside)
						
						$unstiffenedDuctRelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$panel_oposite->id,$check_unstiffened['id']);
						$stiffeners = Calculator::getStiffeners($panelid->id,$materialtype);
						
						$width_stiffiner =json_decode(json_encode($stiffeners), true);
						$countcombinedstiffiner=count($width_stiffiner);
						$isinteresct=array_intersect(array_column($width_stiffiner,'spacing'),array_column($check_unstiffened_comp,'spacing'));
						
						
					}else{
						$panelid=Calculator::getDuctPanelID($height,$materialtype);
						$commone_spacing=$this->getCommonStiffener($postData);
						
						$stiffeners = Calculator::getSpacingID($panelid->id,$materialtype,$commone_spacing);
						
					}
					
				}else{
					$commone_spacing=$this->getCommonStiffener($postData);
					$stiffeners = Calculator::getSpacingID($panelid->id,$materialtype,$commone_spacing);
				}
				
			}
			
			foreach($stiffeners as $key=>$stiff){
					$ductspacingid=$stiff->id;
					
						if($actualpaneldata['width']>$actualpaneldata['height'] && !isset($postData['left_panel'])){
							if(!empty($check_unstiffened)){
								
								$ductspacingid=$this->getDuctSpacingId($check_unstiffened,$check_unstiffened_comp,$stiff->spacing);
							}
						}
							
					
					
					$paneweightcom=$wss+$designPressure;
					$Wsd=0;
					$wss=0;
				
					if(!empty($mingage) && !empty($maxgage) && !isset($postData['yesunfixed'])){
						$exp1=explode('_',$mingage);
						$mingage=$exp1[0];
						$mingagethkiness=isset($exp1[1])?$exp1[1]:'';
						$exp2=explode('_',$maxgage);
						$maxgage=$exp2[0];
						$maxgagethickness=isset($exp2[1])?$exp2[1]:'';
						$mingageObj=Calculator::getGageID($materialtype,$mingage);
						$maxgageObj=Calculator::getGageID($materialtype,$maxgage);
						$mingageid=$mingageObj->id;
						$maxgageid=$maxgageObj->id;
						$getAllgageObj=Calculator::getAllGageId($materialtype,$mingageid,$maxgageid);
						$allgageid=array_column(json_decode($getAllgageObj,true),'id');
						$ductspacingid=isset($spacing_id_array[$key])?$spacing_id_array[$key]:$check_unstiffened['id'];
						$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid,$allgageid);
						
						}else if(!empty($gagedropid) && empty($gap_panel_id)){
							
							$check_unstiffened=$this->checkUnstiffenedExist($stiffeners_oposite);
							if(isset($postData['middle_fixed_yes'])&& ($width!=$height) && !empty($check_unstiffened)){
								
								
								$ductspacingid=isset($postData['stiffSpacingId'][2])?$postData['stiffSpacingId'][2]:$postData['stiffSpacingId'][0];
								$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid,$gagedropid);
									
							}else{
								
								$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid,$gagedropid);

							}
							
						}else if(!empty($checkgage)){
							
							$ductspacingid=isset($spacing_id_array[$key])?$spacing_id_array[$key]:$check_unstiffened['id'];
							$check=explode('_',$checkgage[$key]);
							$getgageid=Calculator::getGageID($materialtype,$check[1]);
							$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid,$getgageid->id);
						}else{
									
							$ductrelation=Calculator::getCriticalLoad($materialtype,$mat_class,$design_temperature,$actualpaneldata['height_id'],$ductspacingid);
							
							
							
							
							//echo $materialtype."--".$mat_class."--".$design_temperature."--".$actualpaneldata['height_id']."--".$ductspacingid;die;
							
						}
						
						
						if(count($ductrelation)>0){
						
							$Wsd=$insweight+$lagingweight;
							$sidePanelArray=$this->process($key,$ductrelation,$height,$paneweightcom,$Wsd,$Wsl,$wss,$sign,$designPressure,'Side',$Wp,$Pw,$postData,$stiff);// Process One calculation
							
							if($sidePanelArray){
							if(!empty($sidePanelArray['id'])){
							
							$sidePanelArray=isset($sidePanelArray['critical_load'])?$sidePanelArray['critical_load']:0;
							if($stiff->spacing!='0.00'){
								$newvar=$this->getReinforcementCalculation($actual_height,round($stiff->spacing,1),$auxmaterialtype,$sidePanelArray,$key,null,$postData);//Reinforcement Calculation
							}
							
								if(!empty($stifinersizeid)){
									$typeid=$stifinersizeid;
									$postData['typeid']=isset($selected_spacing_id_array)?$selected_spacing_id_array[$key]:'';
									$defaultflag=0;
								}else if($min_max_array){
									$typeid=$min_max_array[$key]['stifiner_size_primary_key'];
									$defaultflag=0;
								}else if(!empty($mingage) && !empty($maxgage) && !isset($postData['fixedLayoutReinforcement'])){
									$typeid=$stiffiner_type_id_primary[$key];
									$defaultflag=0;
									$postData['typeid']=$typeid;
									$stiffener_type_id=$typeid;
								}else{
									$defaultflag=1;
									$typeid=isset($newvar->aux_stiffener_type_id)?$newvar->aux_stiffener_type_id:'';
									$stiffener_type_id=$typeid;
							}
							
							
							if($stiff->spacing!='0.00'){
								if($postData['transverse']=='Connecting Flanges'){
										$connectinflangeDefaultSize=Calculator::getConnectingDefaultSiffenerSize($auxmaterialtype,$stiffener_type_id,1);
										$connectingFlangearr=[];
										$connectingFlangearr['duct_length']=isset($postData['duct_length'])?$postData['duct_length']:4;
										$connectingFlangearr['connectingFlangeQualify']=isset($postData['connectingFlangeQualify'])?$postData['connectingFlangeQualify']:1;
										$connectingFlangearr['stiffiner_spacing']=$stiff->spacing;
										$connectingFlangearr['stiffener_type_id']=$stiffener_type_id;
										$connectingFlangearr['stiffener_type']='R'.$stiffener_type_id;
										$connectingFlangearr['primary_stiffener_type_id']=$connectinflangeDefaultSize->id;
										$wss=$this->connectingFlangeDoCount($connectingFlangearr,$auxmaterialtype);
									}else{
										$wss=$this->getStiffinerLoad($auxmaterialtype,$typeid,$defaultflag,$stiff->spacing);
									}
							 }
							$Wsd=0;
							$Wsd=$insweight+$lagingweight;	
							//Super imposed dead load
							$paneweightcom=round($Wsd+$designPressure,2);// add wsd to calculate critical load
							$sidePanelArray=$this->process($key,$ductrelation,$height,$paneweightcom,$Wsd,$Wsl,$wss,$sign,$designPressure,'Side',$Wp,$Pw,$postData,$stiff);
							
							//Process 2 Calculation
							$retrackstiffinertype=array();
							if($stiff->spacing!='0.00'){
								$retrackstiffinertype=$this->getReinforcementCalculation($actual_height,$stiff->spacing,$auxmaterialtype,$sidePanelArray['critical_load'],$key,null,$postData);// Second Time  capacity calculation
							}
							
							
							$sidedesignoption=$this->getAuxiliaryArray($retrackstiffinertype,$sidePanelArray,$wss,$design_temperature,$auxmaterialtype,$ductspacingid,$postData);
								
							
							
							
							}else{
									$sidedesignoption['critical_load'] =0;
									$sidedesignoption['aux_stiffener_type_id'] =0;
									$sidedesignoption['stiffiner_spacing'] =$stiff->spacing;
									$sidedesignoption['spacing_id'] = 0;
									$sidedesignoption['stiffiner_type'] =0;
									$sidedesignoption['stiffiner_load'] = 0;
									$sidedesignoption['stiffiner_capacity'] = 0;
									$sidedesignoption['stiffiner_capacity_unfixed'] =0;
									$sidedesignoption['panel_pressure'] = 0;
									$sidedesignoption['panel_deflection'] =0;
									$sidedesignoption['panel_gage_number'] =0;
									$sidedesignoption['panel_weight'] =0;
									$sidedesignoption['thickness'] =0;
									$sidedesignoption['material_thickness_id'] =0;
									$sidedesignoption['duct_material_gage_id'] =0;
									$sidedesignoption['stifiner_load'] =0;
							}
							$sidePanel[$key]=$sidedesignoption;	
							
						}
					
				}
				
			}
			
				
		}
		
			
		if($countcombinedstiffiner!=$heightcount){//&& empty($stiffeners_sameside)
			$sidePanel=$this->mappingOnUnstiffined($sidePanel,$unstiffenedDuctRelation,$isinteresct,$materialtype,$mat_class,$design_temperature,$panel_oposite->id,$check_unstiffened);
		}
		
		
		//if(isset($postData['unfixed_flag'])){
				
		//	}
		
		
		return $sidePanel;
	}catch(Exception $e){
		
	echo $e->getMessage();	
		
	}
		
		
	}
	
	
	
	
	 
	
	  /** 
		* author						: IDS Infotech Limited
		* function						: getFixedDesignOption()
		* Purpose						: its pupose to create a design condition
		* description					: NA
		* Argument						: NA
		* created						: 08 August 2018
		* modified						: NA
	 */
	
	public function getFixedDesignOption($panels=array()){
		
		
			$design=array();
					for($i=0;$i<count($panels);$i++){

						if(isset($panels['toppanel'][$i])){
							
							$getgageOb=Calculator::getGageID(1,$panels['toppanel'][$i]['panel_gage_number']);
							$heaviergage=Calculator::getHeavierGage($getgageOb->id,1);
							$des1=array();
							foreach($heaviergage as $gkey=>$gage){				
								$des1[$gage->id]=$gage->gage_number;					
							}
							
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['gage']=$panels['toppanel'][$i]['panel_gage_number'];
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['gage_arr']=$des1;
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['panel_pressure']=$this->roundUpToDecimal($panels['toppanel'][$i]['panel_pressure'],1);
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['panel_deflection']=$this->roundUpToDecimal($panels['toppanel'][$i]['panel_deflection'],2);
							
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['stiffener_type']=$panels['toppanel'][$i]['stiffiner_type'];
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['stiffiner_capacity']=$this->roundUpToDecimal($panels['toppanel'][$i]['stiffiner_capacity'],1);
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['critical_load']=$this->roundUpToDecimal($panels['toppanel'][$i]['critical_load'],1);
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['connecting_flang']='NA';
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['connecting_flang_capacity']='NA';
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['condition']='NA';
							$design[$panels['toppanel'][$i]['stiffiner_spacing']]['Top^'.$panels['toppanel'][$i]['aux_stiffener_type_id']]['action']='NA';
							
							
						}
						if(isset($panels['bottompanel'][$i])){
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['gage']=$panels['bottompanel'][$i]['panel_gage_number'];
							//~ $design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['gage_arr']=$panels['bottompanel'][$i]['panel_gage_number'];
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['panel_pressure']=$this->roundUpToDecimal($panels['bottompanel'][$i]['panel_pressure'],1);
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['panel_deflection']=$this->roundUpToDecimal($panels['bottompanel'][$i]['panel_deflection'],2);
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['stiffener_type']=$panels['bottompanel'][$i]['stiffiner_type'];
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['stiffiner_capacity']=$this->roundUpToDecimal($panels['bottompanel'][$i]['stiffiner_capacity'],1);
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['critical_load']=$this->roundUpToDecimal($panels['bottompanel'][$i]['critical_load'],1);
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['connecting_flang']='NA';
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['connecting_flang_capacity']='NA';
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['condition']='NA';
							$design[$panels['bottompanel'][$i]['stiffiner_spacing']]['Bottom^'.$panels['bottompanel'][$i]['aux_stiffener_type_id']]['action']='NA';
							
						}
						if(isset($panels['sidepanel'][$i])){
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['gage']=$panels['sidepanel'][$i]['panel_gage_number'];
							//~ $design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['gage_arr']=$panels['sidepanel'][$i]['panel_gage_number'];
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['panel_pressure']=$this->roundUpToDecimal($panels['sidepanel'][$i]['panel_pressure'],1);
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['panel_deflection']=$this->roundUpToDecimal($panels['sidepanel'][$i]['panel_deflection'],2);
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['stiffener_type']=$panels['sidepanel'][$i]['stiffiner_type'];
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['stiffiner_capacity']=$this->roundUpToDecimal($panels['sidepanel'][$i]['stiffiner_capacity'],1);
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['critical_load']=$this->roundUpToDecimal($panels['sidepanel'][$i]['critical_load'],1);
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['connecting_flang']='NA';
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['connecting_flang_capacity']='NA';
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['condition']='NA';
							$design[$panels['sidepanel'][$i]['stiffiner_spacing']]['Sides^'.$panels['sidepanel'][$i]['aux_stiffener_type_id']]['action']='NA';
							
										}
						
					}
				
					
			return $design;
				
		
	}
	
	  /** 
		* author						: IDS Infotech Limited
		* function						: getParticluate()
		* Purpose						: its pupose to display density on the basis of particulate
		* description					: By using this action we will display density and % full in input box
		* Argument						: NA
		* created						: 25 April 2018
		* modified						: NA
	 */
	
	public function getParticluate(Request $request){
		
			
			if($request->ajax()){
				$requestData=$request->all();
				$designcon=DesignCondition::isExist(base64_decode($requestData['project_id']));
				$particulateData = Calculator::getParticulateDensity($requestData['particulate_id']);
				echo json_encode(['particulate'=>$particulateData,'designcon'=>$designcon]);die;
			}
	}
	
	  /** 
		* author						: IDS Infotech Limited
		* function						: getInsulationDensity()
		* Purpose						: Its pupose to display Insulation density in dropdown
		* description					: This is use for ajax call
		* Argument						: passed parameter inside function
			*$request					: $request will have all request data either get or post via ajax 
		* created						: 25 April 2018
		* modified						: NA
	 */
	
	public function getInsulationDensity(Request $request){
		
			
			if($request->ajax()){
				$requestData=$request->all();
				
				$insdensitydata = Calculator::getInsDensity($requestData['ext_ins_type_id']);
				
				$insthickness = Calculator::getInsulationThick($requestData['ext_ins_type_id']);
				echo json_encode(['insdensity'=>$insdensitydata,'insthickness'=>$insthickness]);die;
			}
	}
	
	  /** 
		* author						: IDS Infotech Limited
		* function						: getInsulationDensity()
		* Purpose						: Its pupose to display Insulation density in dropdown
		* description					: This is use for ajax call
		* Argument						: passed parameter inside function
			*$request					: $request will have all request data either get or post via ajax 
		* created						: 25 April 2018
		* modified						: NA
	 */
	
	public function getLagingThickness(Request $request){
		
			
			if($request->ajax()){
				$requestData=$request->all();
				$lagingdata = Calculator::getLagingThickness($requestData['laging_material_id']);
				
				echo json_encode(['laging'=>$lagingdata]);die;
			}
	}
	
	
	
	/** 
		* author						: IDS Infotech Limited
		* function						: getLiners()
		* Purpose						: Its pupose to display Liner  density and thickness in dropdown
		* description					: This is use for ajax call
		* Argument						: passed parameter inside function
			*$request					: $request will have all request data either get or post via ajax 
		* created						: 26 April 2018
		* modified						: NA
	 */
	
	public function getLiners(Request $request){
		
			
			if($request->ajax()){
				$requestData=$request->all();
				$linerdensitydata = Calculator::getLinerDensity($requestData['liner_material_id']);
				$linerthicknessdata = Calculator::getLinerThickness($requestData['liner_material_id']);
				echo json_encode(['density'=>$linerdensitydata,'thickness'=>$linerthicknessdata]);die;
			}
	}
	
	
	
	
	/** 
		* author						: IDS Infotech Limited
		* function						: saveCustomParticulate()
		* Purpose						: its pupose to save custom particulate
		* description					: NA
		* Argument						: NA
		* created						: 03 May 2018
		* modified						: NA
	 */
	
	public function saveCalculatedData(Request $request){
			$requestData=$request->all();
			
			if($request->post()){
				$customObj=new DesignCondition;
				
				$projectcode=base64_decode($requestData['project_code']);
				
				$exist=DesignCondition::isExist($projectcode);
				
				if(!$exist){
					$customObj->project_id =base64_decode($requestData['project_id']);
					$customObj->project_code =base64_decode($requestData['project_code']);
					$customObj->custom_particulate =$requestData['custom_material'];
					$customObj->save();
				}
				return view('calculator/index'); 
			 }
	}
	 
	
	  
	/** 
		* author						: IDS Infotech Limited
		* function						: process()
		* Purpose						: its pupose to call process function for all panel calucltion
		* description					: It will be called twice in each panels and prepare panels array
		* Argument						: NA
		* created						: 03 May 2018
		* modified						: NA
	 */
	
	private function process($key=null,$ductrelation=null,$width=null,$paneweightcom=null,$Wsd=null,$Wsl=null,$wss=null,$sign=null,$designPressure=null,$type=null,$Wp=null,$Pw=null,$postData=array(),$stiff=null){
		$topPanelArray=array();
		$internalSupportLoad=array();
					
				foreach($ductrelation as $key1=>$drelation)
				{		
					$panelpresser=round($drelation->pr,2);
					if($sign=='Negative'){
						
						if($type=='Top' && $postData['vertical_horigental']=='Horizontal'){
							
							if($type=='Top' && $postData['internal_support']=='Yes'){ //calculate one interval support on load
								
								$critical_load = $this->calculateInternalSupportCriticalLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData);								
								$internalSupportLoad = $this->calculateInternalSupportLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData,$stiff);								
								
							}else{
							 	$critical_load=$designPressure+$Wsd+$drelation->weight+$Wsl+$wss;
							}
							
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff,$internalSupportLoad);
									
							
						}else if($type=='Bottom' && $postData['vertical_horigental']=='Horizontal'){
							
							if($type=='Bottom' && $postData['internal_support']=='Yes'){ //calculate one interval support on load
								
								$critical_load = $this->calculateInternalSupportCriticalLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData);	
								$internalSupportLoad = $this->calculateInternalSupportLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData,$stiff);								
								
							}else{
								$topshutdown=$drelation->weight+$Wsd+$Wp+$wss;
							
								$topoperating=$designPressure-$drelation->weight-$Wsd-$wss;
								
								
								 if($topshutdown>$topoperating)
								{
									$critical_load=$topshutdown;
								}else{
									$critical_load=$topoperating;
								}
							}
							
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff,$internalSupportLoad);
							
							
							
						}else if($type=='Side'){
							$topshutdown=0.1*$Wp+0.4*$Pw;	
							$topoperating=$designPressure+$Pw;
							if($topshutdown>$topoperating)
							{
								$critical_load=$topshutdown;
							}else{
								$critical_load=$topoperating;
							}
						
							
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff);
						}else if($postData['vertical_horigental']=='Vertical'){
							
							if($postData['internal_support']=='Yes'){ //calculate one interval support on load
								
								$critical_load = $this->calculateInternalSupportCriticalLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData);								
								$internalSupportLoad = $this->calculateInternalSupportLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData,$stiff);
								
							}else{
								$topshutdown=0.1*$Wp+0.4*$Pw;	
								$topoperating=$designPressure+$Pw;
								if($topshutdown>$topoperating)
								{
									$critical_load=$topshutdown;
								}else{
									$critical_load=$topoperating;
								}
							}
							
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff,$internalSupportLoad);
							
							
						}
						
					}else if($sign=='Positive'){
						
						if($type=='Top' && $postData['vertical_horigental']=='Horizontal'){
							
							if($type=='Top' && $postData['internal_support']=='Yes'){ //calculate one interval support on load
								
								$critical_load = $this->calculateInternalSupportCriticalLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData);								
								$internalSupportLoad = $this->calculateInternalSupportLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData,$stiff);
								
							}else{
								$topshutdown=$drelation->weight+$Wsd+$Wsl+$wss;
								$topoperating=$designPressure-$drelation->weight-$Wsd-$wss;
							
								if($topshutdown>$topoperating)
								{
									$critical_load=$topshutdown;
								}else{
									$critical_load=$topoperating;
								}
							}
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff,$internalSupportLoad);
							
						}else if($type=='Bottom' && $postData['vertical_horigental']=='Horizontal'){
							
							if($type=='Top' && $postData['internal_support']=='Yes'){ //calculate one interval support on load
								
								$critical_load = $this->calculateInternalSupportCriticalLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData);								
								$internalSupportLoad = $this->calculateInternalSupportLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData,$stiff);
								
							}else{
								$critical_load=$designPressure+$drelation->weight+$Wsd+$wss+$Wp;
							}
							
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff,$internalSupportLoad);
							
							}else if($type=='Side'){
							
								$topshutdown=$Pw;	
								$topoperating=$designPressure+0.1*$Wp+0.4*$Pw;
								if($topshutdown>$topoperating)
								{
									$critical_load=$topshutdown;
								}else{
									$critical_load=$topoperating;
								}
								$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff);
							
						}else if($postData['vertical_horigental']=='Vertical'){
							
							if($postData['internal_support']=='Yes'){ //calculate one interval support on load
								
								$critical_load = $this->calculateInternalSupportCriticalLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData);								
								$internalSupportLoad = $this->calculateInternalSupportLoad($drelation->weight,$Wsd,$Wsl,$wss,$sign,$designPressure,$type,$Wp,$Pw,$postData,$stiff);
								
							}else{
								$topshutdown=0.1*$Wp+0.4*$Pw;	
								$topoperating=$designPressure+$Pw;
								if($topshutdown>$topoperating)
								{
									$critical_load=$topshutdown;
								}else{
									$critical_load=$topoperating;
								}							
							}
							
							$topPanelArray=$this->createDuctRelaionArray($key,$drelation,$width,$critical_load,$stiff,$internalSupportLoad);
							
						}
					}
					
					
					$flag=0;
					if($panelpresser>=$critical_load)
					{		
							$flag=1;
							break;
					}
							
					
				}
				
				if($flag!=1){
					$topPanelArray['id']='';
					$topPanelArray['pr']='0.00';
					$topPanelArray['df']='0.00';
					$topPanelArray['material_thickness_id']='NA';
					$topPanelArray['duct_material_gage_id']='NA';
					$topPanelArray['duct_material_weight_id']='NA';
					$topPanelArray['gage_number']=$drelation->gage_number;
					$topPanelArray['weight']='NA';
					$topPanelArray['spacing']=isset($stiff->spacing)?$stiff->spacing:$stiff;
					$topPanelArray['panel_width']=$drelation->panelwidth;
					$topPanelArray['critical_load']=$topPanelArray['critical_load'];
					$topPanelArray['thickness']=$drelation->thickness;
					$topPanelArray['internal_support_load']=isset($internalSupportLoad)?$internalSupportLoad:'NA';
					
				}
				
				return $topPanelArray;
			
	}
	
	private function zoneAndSnowCal($Wice=null,$Wsnow=null){
			$Wice=$Wice*ZONEMULTIPLYER*PARTICULATEDENCONST;
			$Wsnow=$Wsnow*LOADSTANDARD;
			$Wsl=$Wice+$Wsnow;	
			return $Wsl;
	}
	private function getParticulateWeight($postData=null){
			$Wp=0;
			
			if(!empty($postData['particulate_material_id'])&&$postData['particulate_material_id']!='None'){
				$depth=($postData['percentage_full']/100)*($postData['duct_height']/12);
				$Wp=round($depth*$postData['perticulate_density']*PARTICULATEDENCONST,2);
			}
			return $Wp;
	}
	
	private function getReinforcementCalculation($width=null,$spacing=null,$auxmaterialtype=null,$panelArray=array(),$key=null,$val=null,$postData=array()){
							
						$newvar=array();
					
						if(isset($postData['stiffiner_comparision'])&&$postData['stiffiner_comparision']==1){
							
							$spacing=isset($postData['actualstiffiner'][0])?$postData['actualstiffiner'][0]:$spacing;
							
						}
						 
						$auxpanelid=Calculator::auxSinglePressureWidth($width);
						
						if(empty($auxpanelid)){
							$width=$width+1;
							$auxpanelid=Calculator::auxSinglePressureWidth($width);
						}
						$interval=Calculator::auxIntervals($spacing);
						
						
						$intvid=!empty($interval)?$interval->id:'';// Need to change
						 
						$stiffenertypeid=(isset($postData['typeid']) && !empty($postData['typeid']))?$postData['typeid']:'';
						
						$reinforcementside=Calculator::getReinForcements($auxpanelid->id,$auxmaterialtype,$intvid,$stiffenertypeid);
						
							
								
						$reinforcementside=$this->setReinForcementArray($reinforcementside,$postData,$auxmaterialtype);
						if(isset($postData['typeid'])){
						
							$reinforce=isset($reinforcementside[0])?$reinforcementside[0]:$reinforcementside;
							return $reinforce;
						}
							
							
							foreach($reinforcementside as $renforce){
								$renforce->value=(string)$renforce->value;
								$panelArray=(string)$panelArray;
								if($renforce->value>=$panelArray){
									
									$newvar=$renforce;
										
									break;
								}	
							}
							
						return $newvar;
	}

	

/** 
	* author						:IDS Infotech Limited
	* function						: connectingFlangeDoCount()
	* Purpose						: Its purpose to calculate stiffener load when connecting flange selected from dropdown
									: default $connectingFlangeQualify will be yes and no will be considered  if you change from   
									  left navigation
	* description					: This will be called to use stiffener load $connectingFlangeQualify='Yes mean 1' and 	
									: $connectingFlangeQualify="No means 0"
	 
	* Argument						: passed parameter inside function
	  $designoptions				: Its desionoption of top,bottom,side
	* created						: 29 Nov 2018
	* modified						: NA
 */
 
 
private function connectingFlangeDoCount($connectingFlangearr=array(),$auxmaterialtype=null){
	
			
			$defaultductlength=$connectingFlangearr['duct_length'];
			$spacing=$connectingFlangearr['stiffiner_spacing'];
			$connectingStatus=$connectingFlangearr['connectingFlangeQualify'];
			$stiffener_type_id=$connectingFlangearr['stiffener_type_id'];
			$flangData=Calculator::getFlangeWeight($connectingFlangearr['primary_stiffener_type_id']);
			
			$stiffener_type=Calculator::stiffenerTypeId($connectingFlangearr['stiffener_type']);
			
			$stiffenerData=Calculator::getDefaultSiffenerSize($auxmaterialtype,$stiffener_type->id,1);
			$connectingweight=$flangData->weight;
			$stiffinerweight=$stiffenerData->weight;
			
			//Do Count Case
			if($connectingStatus==1){
				$stiffenerQuantity=$defaultductlength/$spacing;
				$afterRound=round($stiffenerQuantity);//1 is static value
				$finalstiffenerQuantity=$afterRound-1;
				$stiffinerWeight=((($stiffinerweight*$finalstiffenerQuantity)/$defaultductlength)*0.192);
				$connectingWeight=(($connectingweight*$finalstiffenerQuantity)/$defaultductlength)*0.192;
				$wsscountasreinforcement=$stiffinerWeight+$connectingWeight;
			}else{
				//Do not Count
				$stiffenerQuantity=$stiffinerweight/$spacing;
				$stiffinerWeight=($stiffenerQuantity*0.192);
				$connectingWeight=(($connectingweight*2)/$defaultductlength)*0.192;//here 2,0.192 is static value
				$wsscountasreinforcement=$stiffinerWeight+$connectingWeight;
			}
		
		
		return $wsscountasreinforcement;
	
}

private function getDeflection($def=null,$cr=null,$pr=null){
		$deflection='0.00';
		if(!empty($pr) && $pr!='0.00'){
			
			$deflection=$def*($cr/$pr);
		}
		return $deflection;
}



/** 
	* author						: IDS Infotech Limited
	* function						: getConnectingFlange()
	* Purpose						: Its pupose to calculate connecting flange type,height,size,bolt hole gage.
									  This will work same gage all side "YES".Here 75% of Inertia is compared with inertia (I power 4) value .If matched found then restult will be stiffener type. Height wil be considered first result of 6 G1 Table  
	* description					: This will be called as qualify as reinforcement.I have calculated moment of   
									  inertia and verify its 75% in respective tables like 6D,7D...
									  
	* Argument						: passed parameter inside function
	  $designoptions				: Its desionoption of top,bottom,side
	* created						: 29 Nov 2018
	* modified						: NA
 */

private function getConnectingFlange($designoptions=null,$postData=null,$maxgage=null){
		$connecting_flange=array();
		$connecting_flange_type='NA';
		$flange_height_pressure='NA';
		$auximaterialtype=$this->getMatterialMapping($postData['duct_material']);
		$gageObj=Calculator::getMaterialGageId($auximaterialtype,$maxgage);
		
		$min_flange_relation=Calculator::getFlange($auximaterialtype,$gageObj->id);
		
		$flange_height_pressure=($postData['positive_negtive_pressure']=='Negative')?$min_flange_relation->negative_pressure:$min_flange_relation->positive_pressure;
		$all_default_stiffener=Calculator::getAllDefaultSiffenerSize($auximaterialtype);
		if(($designoptions['stiffener_spacing']!='0.0')){
		$top=substr($designoptions['stiffener_type_top'],1);
		$bot=substr($designoptions['stiffener_type_bottom'],1);
		$side=substr($designoptions['stiffener_type_side'],1);
		if (filter_var($top, FILTER_VALIDATE_INT) === false ) {
			$top=0;
		}
		if (filter_var($bot, FILTER_VALIDATE_INT) === false ) {
			$bot=0;
		}
		if (filter_var($side, FILTER_VALIDATE_INT) === false ) {
			$side=0;
		}
		$max_stiffeners_type_id=max($top,$bot,$side);
		$default_stiffener=Calculator::getDefaultSiffenerSize($auximaterialtype,$max_stiffeners_type_id,1);
		$explode=explode('x',$default_stiffener->size);
		$default_size_height=$explode[0];
		$default_height=$this->convertFractionTodecimal($default_size_height);
		$moment_inertia=$default_stiffener->large;
		$to_qualify_reinforcement=0.75*$moment_inertia;

		// flange height comparison with stiffener

		$connecting_flange_type='';
		foreach($all_default_stiffener as $getstiffenertype){
			if($getstiffenertype->large>=$moment_inertia){
				$connecting_flange_type='R'.$getstiffenertype->stiffener_type_id;
				break;
			}
		}

		$flang_g1_height=$this->convertFractionTodecimal($flange_height_pressure);

		
		$bolt_hole=Calculator::getBoltHole($auximaterialtype,$flange_height_pressure);

		}else{

		foreach($all_default_stiffener as $key=>$getstiffenertype){
			$explode=explode('x',$getstiffenertype->size);
			$size_height=$explode[0];
			$size_height=$this->convertFractionTodecimal($size_height);
			
			if($size_height>=$flange_height_pressure){
				$connecting_flange_type='R'.$getstiffenertype->stiffener_type_id;
					break;
			}
		}

		}


		$connecting_flange['stiffener_type_id']=substr($connecting_flange_type,1);
		$connecting_flange['connecting_flange_type']=$connecting_flange_type;
		
		$connecting_flange['connecting_flange_height']=$flange_height_pressure;
		$connecting_flange['size']=isset($min_flange_relation->size)?$min_flange_relation->size:'NA';
		$connecting_flange['bolt_value']=isset($min_flange_relation->bolt_value)?$min_flange_relation->bolt_value:'NA';
		$connecting_flange['bolt_hole_gage']=isset($bolt_hole->bolt_hole_gage)?$bolt_hole->bolt_hole_gage:'NA';

		return $connecting_flange;
		
		
	}
	
	/** 
	* author						: IDS Infotech Limited
	* function						: getConnectingFlangeNo()
	* Purpose						: Its pupose to calculate connecting flange type,height,size,bolt hole gage.
									  This will work same gage all side "NO".To get Stiffener type we will compare default stiffener size like 2 1/2 X 2X 1/2 with 2 1/2 where matched will be considered stiffener type.
	* description					: This will be called as do not qualify as reinforcement.There is no need to use moment of inertia
	* Argument						: passed parameter inside function
	  $designoptions				: Its desionoption of top,bottom,side
	* created						: 29 Nov 2018
	* modified						: NA
 */
	
	
	private function getConnectingFlangeNo($designoptions=null,$postData=null,$maxgage=null){
				
					$connecting_flange=array();
					$connecting_flange_type='NA';
					$flange_height_pressure='NA';
					
					
					$top=substr($designoptions['stiffener_type_top'],1);
					$bot=substr($designoptions['stiffener_type_bottom'],1);
					$side=substr($designoptions['stiffener_type_side'],1);
					$max_stiffeners_type_id=max($top,$bot,$side);
					$auximaterialtype=$this->getMatterialMapping($postData['duct_material']);
					$gageObj=Calculator::getMaterialGageId($auximaterialtype,$maxgage);
					if(isset($gageObj) && $gageObj!=''){
						$min_flange_relation=Calculator::getFlange($auximaterialtype,$gageObj->id);
						$flange_height_pressure=($postData['positive_negtive_pressure']=='Negative')?$min_flange_relation->negative_pressure:$min_flange_relation->positive_pressure;
						$all_default_stiffener=Calculator::getAllDefaultSiffenerSize($auximaterialtype);	
						if(($designoptions['stiffener_spacing']!='0.0')){
							
							$default_size_height=$this->convertFractionTodecimal($flange_height_pressure);
							
							$selectdefaultstiffener=array();
							
							foreach($all_default_stiffener as $key=>$getstiffenertype){
								$explode=explode('x',$getstiffenertype->size);
								$size_height=$explode[0];
								$size_height=$this->convertFractionTodecimal($size_height);
								
								if($size_height>=$default_size_height){
									$selectdefaultstiffener['moment_inertia']=$getstiffenertype->large;
									$selectdefaultstiffener['stiffener_type_id']=$getstiffenertype->stiffener_type_id;
									$selectdefaultstiffener['size']=$getstiffenertype->size;
										break;
								}
							}
							
							$connecting_flange_type='R'.$selectdefaultstiffener['stiffener_type_id'];
							
							$bolt_hole=Calculator::getBoltHole($auximaterialtype,$flange_height_pressure);
						}else{
							
							foreach($all_default_stiffener as $key=>$getstiffenertype){
								$explode=explode('x',$getstiffenertype->size);
								$size_height=$explode[0];
								$size_height=$this->convertFractionTodecimal($size_height);
								
								if($size_height>=$flange_height_pressure){
									$connecting_flange_type='R'.$getstiffenertype->stiffener_type_id;
										break;
								}
							}
							
							}
					}
				$connecting_flange['connecting_flange_type']=$connecting_flange_type;
				$connecting_flange['connecting_flange_height']=$flange_height_pressure;
				$connecting_flange['size']=isset($min_flange_relation->size)?$min_flange_relation->size:'NA';
				$connecting_flange['bolt_hole_gage']=isset($bolt_hole->bolt_hole_gage)?$bolt_hole->bolt_hole_gage:'NA';
				$connecting_flange['bolt_value']=isset($min_flange_relation->bolt_value)?$min_flange_relation->bolt_value:'NA';
				//echo '<pre>';print_r($connecting_flange);die;
				return $connecting_flange;
		
		
	}	
	
	
	
	
	
	/** 
		* author						: IDS Infotech Limited
		* function						: removeSession()
		* Purpose						: Its pupose to remove session of left panel on tab switching like fixed to 	
										  unfixed and vice versa
		* description					: NA
		* Argument						: NA
		* created						: 23 Nov 2018
		* modified						: NA
	 */
	public function removeSession(){
		session_start();
		if(isset($_SESSION['spacing_val'])){
			unset($_SESSION['spacing_val']);
			unset($_SESSION['old_session_val']);
		}
	}
	
	 /** 
		* author						: IDS Infotech Limited
		* function						: updateStiffenerMinMaxGage()
		* Purpose						: Its pupose to calculate Stiffener Sizing Options and Panel Gage Design Options
		* description					: NA
		* Argument						: NA
		* created						: 22 Octber 2018
		* modified						: NA
	 */
	
	
	public function updateStiffenerMinMaxGage(Request $request){
		
		try{
		$postData=$request->all();
		$des=array();
		$returndropdown=array();
		
		$formData=$this->chageJsonObjToArr($postData['formData']);	
		$formData=$this->getDataBaseMapping($formData);
		$postData['formData']=$formData;
		$requestData = $formData;
		$layoutType = $postData['layoutType'];
		$duct_material=$requestData['duct_material'];
		$requestData['min_max']=1;
		$requestData['left_panel']=1;
		$auxmaterialtype=$this->getMatterialMapping($duct_material);
		session_start();
		
	if($layoutType=='fixedStiffenerYes'){
		
		if(isset($_SESSION['spacing_val']) && !empty($_SESSION['spacing_val'])){//echo '<pre>'; 
			unset($_SESSION['spacing_val']['min_stiffener_size']);//
			unset($_SESSION['spacing_val']['max_stiffener_size']);
			
			$_SESSION['spacing_val']['max_stiffener_size']=$postData['max_stiffener_size'];
			$_SESSION['spacing_val']['min_stiffener_size']=$postData['min_stiffener_size'];
			$_SESSION['old_session_val']['max_stiffener_size']=$postData['max_stiffener_size'];
			$_SESSION['old_session_val']['min_stiffener_size']=$postData['min_stiffener_size'];
			if($postData['rangeFlag']==1){
				$checkgage=$this->getAllDesignOptionData($_SESSION['old_session_val']['gageCheck'],$_SESSION['old_session_val']);
			}
			else{
			   $checkgage=$this->getAllDesignOptionData($postData['gageCheck'],$postData);	
			}
			
		}else{
			
			$checkgage=$this->getAllDesignOptionData($postData['gageCheck'],$postData);
			if(!isset($_SESSION['spacing_val']) && empty($_SESSION['spacing_val'])){			
				$_SESSION['old_session_val']=$postData;
			}
			$_SESSION['spacing_val']=$postData;
			
						
		}
		
		$toppanel=$this->getTopCriticalLoad($requestData,null,null,$checkgage['Top'],$postData['max_stiffener_size'],$postData['min_stiffener_size']);
		 
		$botpanel=$this->getBottomCriticalLoad($requestData,null,null,$checkgage['Bottom'],$postData['max_stiffener_size'],$postData['min_stiffener_size']);
		$sidepanel=$this->getSidePanelCriticalLoad($requestData,null,null,$checkgage['Sides'],$postData['max_stiffener_size'],$postData['min_stiffener_size']);
		$crLoads['toppanel']=$toppanel;
		$crLoads['bottompanel']=$botpanel;
		$crLoads['sidepanel']=$sidepanel;
		
		$sizearrayTop=array_column($checkgage['Top'],'spacing');
		
		$designoptions=$this->getDesignOptions($formData,$crLoads,null,$sizearrayTop);
		
			if($postData['same_size_gage']==1 || $postData['same_size_gage']==2 ||  empty($postData['same_size_gage'])){ // Reverse calculation
			
				$checkgage=$this->getAllDesignOptionData($_SESSION['old_session_val']['gageCheck'],$_SESSION['old_session_val']);
				
				$checkgage=$this->checkTopAndBottom($checkgage,$postData['same_size_gage']);
				
				$toppanel=$this->getTopCriticalLoad($requestData,null,null,$checkgage['Top'],$postData['max_stiffener_size'],$postData['min_stiffener_size']);
				$botpanel=$this->getBottomCriticalLoad($requestData,null,null,$checkgage['Bottom'],$postData['max_stiffener_size'],$postData['min_stiffener_size']);
				$sidepanel=$this->getSidePanelCriticalLoad($requestData,null,null,$checkgage['Sides'],$postData['max_stiffener_size'],$postData['min_stiffener_size']);
				$crLoads['toppanel']=$toppanel;
				$crLoads['bottompanel']=$botpanel;
				$crLoads['sidepanel']=$sidepanel;
				$designoptions=$this->getDesignOptions($formData,$crLoads,null,$sizearrayTop);
				
			}
			$returndropdown=$this->stiffenerDropdown($designoptions,$auxmaterialtype);
		}else if($layoutType=='unfixedStiffenerYes'){
			
			$designoptions=$this->getUnfixedLeftPanel($postData);
			$returndropdown=$this->stiffenerDropdown($designoptions,$auxmaterialtype);
			
		}
		else if($layoutType=='fixedStiffenerNo'){
			
			 $designoptions=$this->getSameGageAllSideNoFixed($postData);
			 $returndropdown=$this->stiffenerDropdown($designoptions,$auxmaterialtype);
		}
		else if($layoutType=='unfixedStiffenerNo'){
				$designOpt=array();
				$designOpt=$this->getSameGageAllSideNoUnFixed($postData);
				
				$designoptions=$designOpt['designoptions'];
				$crLoads=isset($designOpt['crLoads'])?$designOpt['crLoads']:'';
			
				$returndropdown=$this->stiffenerDropdownNo($crLoads,$auxmaterialtype);
			
		}
		$des=array();
		
	    if($requestData['same_gage']=="Yes"){
			if($layoutType=="unfixedStiffenerYes"){
				
				$des=$this->getLayoutArrForYesUnfixed($designoptions,$postData['max_stiffener_size'],$duct_material,$requestData['same_gage'],null);
			}else{				
				$des=$this->getLayoutArr($designoptions,$postData['max_stiffener_size'],$duct_material,$requestData['same_gage'],null);
				
			}
			
		}elseif($requestData['same_gage']=="No"){
			if($layoutType=="fixedStiffenerNo"){
				$des=$this->getLayoutArrForNofixed($designoptions,null,$duct_material,$requestData['same_gage'],null);					
			}elseif($layoutType=="unfixedStiffenerNo"){
				
				$des=$designoptions;
			}
		}
		unset($des[0]);
		
		echo json_encode(['des'=>$des,'dropdown'=>$returndropdown]);
		die;
		}catch(Exception $e){
			
			echo $e->getMessage();die;
		}
		
	}
	
	
	
	
	/** 
		* author						: IDS Infotech Limited
		* function						: getAllDesignOptionData()
		* Purpose						: Its pupose to create an array for gage check parameter that will helpout to get stiffiner spacing 
											,its id and other fields
		* description					: NA
		* Argument						: NA
		* created						: 22 Octber 2018
		* modified						: NA
	 */
	private function getAllDesignOptionData($gageCheck=array(),$postData){
		$get_required_spacing=array();
		$get_outer_spacing=array();
		$i=0;
		$getThickness=explode('_',$postData['max_stiffener_size']);
		$maxthickness=isset($getThickness[1])?$getThickness[1]:'';
			
		$materialtype=$postData['formData']['duct_material'];
		$i=0;foreach($gageCheck as $key=>$check){
				
				$panels=explode('_',$check);
				$checkgage=isset($panels['1'])?$panels['1']:'';
				$maxgageObj=Calculator::getGageID($materialtype,$checkgage);
			
				$getthkOb=Calculator::getThickness($materialtype,$maxgageObj->id);
				
						if($i==0){
							
							$get_required_spacing['Top'][$key]['spacing']=$panels[0];
							$get_required_spacing['Top'][$key]['stiffiner_type_id_primary']=isset($panels[3])?$panels[3]:'NA';
							$get_required_spacing['Top'][$key]['spacing_id']=isset($panels[4])?$panels[4]:'NA';
							$get_required_spacing['Top'][$key]['stiffiner_type_id']=isset($panels[2])?$panels[2]:'NA';
							
						}else if($i==1){
							
							$get_required_spacing['Bottom'][$key]['spacing']=$panels[0];
							$get_required_spacing['Bottom'][$key]['stiffiner_type_id_primary']=isset($panels[3])?$panels[3]:'NA';
							$get_required_spacing['Bottom'][$key]['spacing_id']=isset($panels[4])?$panels[4]:'NA';
							$get_required_spacing['Bottom'][$key]['stiffiner_type_id']=isset($panels[2])?$panels[2]:'NA';
							
						}else if($i==2){
							$get_required_spacing['Sides'][$key]['spacing']=$panels[0];
							$get_required_spacing['Sides'][$key]['stiffiner_type_id_primary']=isset($panels[3])?$panels[3]:'NA';
							$get_required_spacing['Sides'][$key]['spacing_id']=isset($panels[4])?$panels[4]:'NA';
							$get_required_spacing['Sides'][$key]['stiffiner_type_id']=isset($panels[2])?$panels[2]:'NA';
						}
			
				if($i==2){
						$i=-1;
					}
				$i++;
				
			}
			
			
			return $get_required_spacing;
		
		
		
	}
	
	
	/** 
		* author						: IDS Infotech Limited
		* function						: getAllDesignOptionNoUnfixed()
		* Purpose						: Its pupose to create an array for gage check parameter that will helpout to get stiffiner spacing 
											,its id and other fields
		* description					: NA
		* Argument						: NA
		* created						: 22 Octber 2018
		* modified						: NA
	 */
	private function getAllDesignOptionNoUnfixed($gageCheck=array(),$postData){
		$get_required_spacing=array();
		$get_outer_spacing=array();
		$i=0;
		$getThickness=explode('_',$postData['max_stiffener_size']);
		$maxthickness=isset($getThickness[1])?$getThickness[1]:'';
			
		$materialtype=$postData['formData']['duct_material'];
		
		
		$i=0;foreach($gageCheck as $key=>$check){
				
				$panels=explode('_',$check);
				$checkgage=isset($panels['1'])?$panels['1']:'';
				$maxgageObj=Calculator::getGageID($materialtype,$checkgage);
				
				$getthkOb=Calculator::getThickness($materialtype,$maxgageObj->id);
						if($panels['5']=='Top'){
							$get_required_spacing['Top'][$key]['spacing']=$panels[0];
							$get_required_spacing['Top'][$key]['stiffiner_type_id_primary']=isset($panels[3])?$panels[3]:'NA';
							$get_required_spacing['Top'][$key]['spacing_id']=isset($panels[4])?$panels[4]:'NA';
							$get_required_spacing['Top'][$key]['stiffiner_type_id']=isset($panels[2])?$panels[2]:'NA';
						}else if($panels['5']=='Bottom'){
							
							$get_required_spacing['Bottom'][$key]['spacing']=$panels[0];
							$get_required_spacing['Bottom'][$key]['stiffiner_type_id_primary']=isset($panels[3])?$panels[3]:'NA';
							$get_required_spacing['Bottom'][$key]['spacing_id']=isset($panels[4])?$panels[4]:'NA';
							$get_required_spacing['Bottom'][$key]['stiffiner_type_id']=isset($panels[2])?$panels[2]:'NA';
							
						}else if($panels['5']=='Sides'){
							$get_required_spacing['Sides'][$key]['spacing']=$panels[0];
							$get_required_spacing['Sides'][$key]['stiffiner_type_id_primary']=isset($panels[3])?$panels[3]:'NA';
							$get_required_spacing['Sides'][$key]['spacing_id']=isset($panels[4])?$panels[4]:'NA';
							$get_required_spacing['Sides'][$key]['stiffiner_type_id']=isset($panels[2])?$panels[2]:'NA';
						}
				
				
				$i++;
				
			}
			
			return $get_required_spacing;
		
		
		
	}
	
}
