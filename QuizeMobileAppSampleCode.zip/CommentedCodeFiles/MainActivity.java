package com.quizapp.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import com.quizapp.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity
{

    @BindView(R.id.btn_start_quiz)
    Button startQuiz;

    @BindView(R.id.tv_title)
    TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

 // Setting the title on the toolbar 
        title.setText(getResources().getString(R.string.str_first_title));
    }


    /* Button click of start quiz */
    @OnClick(R.id.btn_start_quiz)
    public void btnStartQuizClick()
    {
        final String response = loadJSONFromAsset();

        Log.e("Json Response","======"+response);

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        startQuiz.startAnimation(myAnim);

 // Timer to start & finish the work in the particular time interval
        Timer buttonTimer = new Timer();
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run()
                    {
                        startActivity(new Intent(MainActivity.this, QuizActivity.class)
                                .putExtra("response",response));
                        }
                        });
                    }
                }, 5000);
        //*/setEnabled(true);

    }


    /* Load & read Json files placed in the assets folder */
    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getAssets().open("questionnaire.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
