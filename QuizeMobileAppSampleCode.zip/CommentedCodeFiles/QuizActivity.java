package com.quizapp.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.quizapp.R;
import com.quizapp.activities.models.Questions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class QuizActivity extends AppCompatActivity
{
     @BindView(R.id.tv_total_quest)
     TextView totalQuestionsCount;

     @BindView(R.id.tv_timer)
     TextView timerValue;

     @BindView(R.id.tv_question)
     TextView questionsText;

     @BindView(R.id.tv_question_number)
     TextView questionsNumber;


     @BindView(R.id.tv_title)
     TextView title;

     @BindView(R.id.btn_previous)
     TextView previousButton;

    @BindView(R.id.btn_next)
    TextView nextButton;

    @BindView(R.id.radioGroupOptions)
    RadioGroup radioGroup;

    @BindView(R.id.radio_button1)
    RadioButton radioButton1;

    @BindView(R.id.radio_button2)
    RadioButton radioButton2;

    @BindView(R.id.radio_button3)
    RadioButton radioButton3;

    @BindView(R.id.radio_button4)
    RadioButton radioButton4;

    MyCountDownTimer countDownTimer = new MyCountDownTimer(40000 /* 40 Sec */,
            1000);

    ArrayList<Questions> questionArrayList = new ArrayList<Questions>();
    ArrayList<HashMap<Integer,String>> attemptedQuestions = new ArrayList<HashMap<Integer,String>>();

    LinkedHashMap linkedHashMap = new LinkedHashMap();

    int totalQuestionsValue = 0, q_id = 0, correct = 0, wrong = 0, score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        ButterKnife.bind(this);

        title.setText(getResources().getString(R.string.str_quiz_title));

        String response = getIntent().getStringExtra("response");

        Log.e("Quiz Activity","===="+response);

        previousButton.setVisibility(View.GONE);

        parseResponse(response);

    }

    @Override
    public void onBackPressed()
    {

// Theme to set
        ContextThemeWrapper themedContext;
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ) {
            themedContext = new ContextThemeWrapper( QuizActivity.this, android.R.style.Theme_Holo_Light_Dialog_NoActionBar );
        }
        else {
            themedContext = new ContextThemeWrapper( QuizActivity.this, android.R.style.Theme_Light_NoTitleBar );
        }

// Alert dialog to show on the screen 
        AlertDialog.Builder builder = new AlertDialog.Builder(themedContext);
        builder.setMessage("Are you sure, you want to quit the quiz?")
            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.dismiss();
                    finish();
                }
            })
            .setNegativeButton("No", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.dismiss();
                }
            })
            .show();

    }

    /* Parsing JSON file response */
    public void parseResponse(String response)
    {

        questionArrayList = new ArrayList<>();
        try
        {
            JSONObject responseObject = new JSONObject(response);
            JSONArray dataArray = responseObject.getJSONArray("data");
            totalQuestionsValue = dataArray.length();

            totalQuestionsCount.setText("Total Questions: "+totalQuestionsValue+"");

            for(int i = 0; i < totalQuestionsValue; i++ )
            {
                JSONObject dataObject = dataArray.getJSONObject(i);
                Questions ques = new Questions();

                ques.q_id = dataObject.getInt("id");
                ques.q_type = dataObject.getString("type");
                ques.question = dataObject.getString("question");
                ques.answer = dataObject.getString("answer");
                ques.option_value1 = dataObject.getString("option_1");
                ques.option_value2 = dataObject.getString("option_2");
                ques.option_value3 = dataObject.getString("option_3");
                ques.option_value4 = dataObject.getString("option_4");

                questionArrayList.add(ques);

            }

            Collections.shuffle(questionArrayList);

            setQuestionView();
            timerValue.setText("Max Time: 40 Secs");
            countDownTimer.start();



        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

    }
    @OnClick(R.id.btn_next)
    public void nextButtonClick()
    {
        radioGroup.setClickable(true);


        if(radioButton1.isChecked() || radioButton2.isChecked() || radioButton3.isChecked() || radioButton4.isChecked())
        {
            countDownTimer.cancel();
            if (getNextQuestion(false)) {
                // Start The timer again
                countDownTimer.start();
            }
        }
        else
        {
            Toast.makeText(this, "Please select atleast 1 option, to move forward",Toast.LENGTH_LONG).show();
        }
    }

    @OnClick(R.id.btn_previous)
    public void previousButtonClick()
    {
        if(q_id > 0)
        {
            q_id --;
            setQuestionView();
            radioGroup.setClickable(false);

            selectedOptions("prev");
        }

    }


    /* Setting the questions & options based on JSON values */
    private void setQuestionView()
    {
        if(q_id == totalQuestionsValue-1)
        {
            nextButton.setText(getResources().getString(R.string.str_submit));
        }

        questionsNumber.setText(q_id+1+ "");//questionArrayList.get(q_id).getQ_id()+""
        questionsText.setText(questionArrayList.get(q_id).getQuestion()); //currentQ.getQUESTION()
        radioButton1.setText(questionArrayList.get(q_id).getOption_value1()); //currentQ.getOPTA()
        radioButton2.setText(questionArrayList.get(q_id).getOption_value2()); //currentQ.getOPTB()
        radioButton3.setText(questionArrayList.get(q_id).getOption_value3()); //currentQ.getOPTC()
        radioButton4.setText(questionArrayList.get(q_id).getOption_value4());

    }

     /* Getting Next question on click of Next button or while Timer time's Up*/
    boolean getNextQuestion(boolean c)
    {

        RadioButton answer = (RadioButton) findViewById(radioGroup
                .getCheckedRadioButtonId());


        if(radioButton1.isChecked() || radioButton2.isChecked() || radioButton3.isChecked() || radioButton4.isChecked())
        {

            selectedOptions("next");

            if (!c && questionArrayList.get(q_id).getAnswer().equals(answer.getText()))
            {
                correct++;
                score = score+2;
            } else {
                linkedHashMap.put(questionArrayList.get(q_id).getQuestion(), questionArrayList.get(q_id).getAnswer());
                wrong++;
            }

            HashMap hm = new HashMap();
            hm.put("id",questionArrayList.get(q_id).getQ_id());
            hm.put("answer",answer.getText());

            attemptedQuestions.add(hm);
        }
        else
        {
            linkedHashMap.put(questionArrayList.get(q_id).getQuestion(), questionArrayList.get(q_id).getAnswer());
            wrong++;

            HashMap hm = new HashMap();
            hm.put("id",questionArrayList.get(q_id).getQ_id());
            hm.put("answer","");

            attemptedQuestions.add(hm);
        }


        q_id++;

        if (q_id < totalQuestionsValue)
        {
            setQuestionView();
        }
        else
        {
            Log.e("Quiz Finished","====="+correct+"====="+wrong);

            Toast.makeText(this, "You have attempted all questions..",Toast.LENGTH_LONG).show();

            startActivity(new Intent(this, ResultActivity.class)
                          .putExtra("correct",correct)
                          .putExtra("wrong",wrong)
                          .putExtra("score",score)
                          .putExtra("attempted",linkedHashMap));
            return false;
        }

        return true;
    }

    /* Already selected radio buttons or options by user */
    public void selectedOptions(String tag_button)
    {
        try
        {
            /*if (!attemptedQuestions.isEmpty())
            {*/
                if(tag_button.equalsIgnoreCase("next"))
                {
                    radioGroup.clearCheck();
                }
                else
                {
                    HashMap hm = attemptedQuestions.get(q_id);
                    if (hm.containsValue("answer"))
                    {
                        String ans = hm.get("answer").toString();

                        if (radioButton1.getText().toString().equalsIgnoreCase(ans)) {
                            radioButton1.setChecked(true);
                        } else if (radioButton2.getText().toString().equalsIgnoreCase(ans)) {
                            radioButton2.setChecked(true);
                        } else if (radioButton3.getText().toString().equalsIgnoreCase(ans)) {
                            radioButton3.setChecked(true);
                        } else if (radioButton4.getText().toString().equalsIgnoreCase(ans)) {
                            radioButton4.setChecked(true);
                        }
                    }
                    else
                    {
                        radioGroup.clearCheck();
                    }
             //   }

            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    /* Setting CountDown Timer */
    public class MyCountDownTimer extends CountDownTimer {
        public MyCountDownTimer(long startTime, long interval) {
            super(startTime, interval);
        }

        public void onFinish() {
            Log.e("Times up", "Times up");
            countDownTimer.cancel();
            if (getNextQuestion(false))
            {
                // Start The timer again
                countDownTimer.start();
            }
        }
        @Override
        public void onTick(long millisUntilFinished) {
            timerValue.setText("Max Time: "+(millisUntilFinished / 1000) + " Secs");
            Log.e("Second Gone", "Another Second Gone");
            Log.e("Time Remaining", "seconds remaining: " + millisUntilFinished
                    / 1000);
        }
    }
}
